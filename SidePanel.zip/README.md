# Side Panel
Floating edge-handle panel for Android: app shortcuts, notes, calculator.
Build: push to GitHub, open Actions > Build APK, download the artifact.
Signed release APK: add the KEYSTORE_BASE64, KEYSTORE_PASSWORD and KEY_ALIAS secrets in repo Settings > Secrets and variables > Actions.
