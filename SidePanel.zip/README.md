# Side Panel
Floating edge-handle panel for Android: app shortcuts, notes, calculator.
Build: push to GitHub, open Actions > Build APK, download the artifact.
