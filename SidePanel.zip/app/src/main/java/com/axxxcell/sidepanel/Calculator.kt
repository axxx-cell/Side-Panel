package com.axxxcell.sidepanel

import kotlin.math.abs
import kotlin.math.floor

/** Tiny recursive-descent evaluator: + − × ÷ ( ) and decimals. */
object Calculator {

    fun evaluate(input: String): String {
        if (input.isBlank()) return ""
        return try {
            val result = Parser(input).parse()
            if (result.isNaN() || result.isInfinite()) "Error"
            else if (result == floor(result) && abs(result) < 1e15) result.toLong().toString()
            else result.toString()
        } catch (e: Exception) {
            "Error"
        }
    }

    private class Parser(raw: String) {
        private val s = raw.replace('×', '*').replace('÷', '/').replace('−', '-').replace(" ", "")
        private var i = 0

        private fun peek(): Char = if (i < s.length) s[i] else '\u0000'

        fun parse(): Double {
            val v = expr()
            require(i == s.length) { "Unexpected input" }
            return v
        }

        private fun expr(): Double {
            var v = term()
            while (peek() == '+' || peek() == '-') {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        private fun term(): Double {
            var v = factor()
            while (peek() == '*' || peek() == '/') {
                val op = s[i++]
                val r = factor()
                v = if (op == '*') v * r else v / r
            }
            return v
        }

        private fun factor(): Double {
            if (peek() == '-') { i++; return -factor() }
            if (peek() == '(') {
                i++
                val v = expr()
                require(peek() == ')') { "Missing )" }
                i++
                return v
            }
            val start = i
            while (peek().isDigit() || peek() == '.') i++
            require(i > start) { "Expected number" }
            return s.substring(start, i).toDouble()
        }
    }
}
