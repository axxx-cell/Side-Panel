package com.axxxcell.sidepanel

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.view.animation.DecelerateInterpolator

/**
 * A dark "sheet" (same colour as the panel) that bulges out from the screen edge
 * while you hold, like pulling the panel out. No circle.
 */
class PullHandleView(context: Context, private val onRight: Boolean = true) : View(context) {

    private val d = resources.displayMetrics.density
    private var progress = 0f
    private var anim: ValueAnimator? = null

    private val sheetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xF0202124.toInt()
        style = Paint.Style.FILL
        setShadowLayer(8f * d, 0f, 0f, Color.argb(110, 0, 0, 0))
    }
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(70, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1f * d
    }
    private val gripPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val path = Path()

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    fun setProgress(p: Float) {
        progress = p.coerceIn(0f, 1f)
        invalidate()
    }

    /** Fills the sheet over [ms] (the hold time), then calls [onDone]. */
    fun animateHold(ms: Long, onDone: () -> Unit) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(progress, 1f).apply {
            duration = ms
            interpolator = DecelerateInterpolator()
            addUpdateListener { setProgress(it.animatedValue as Float) }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    if (progress >= 1f) onDone()
                }
            })
            start()
        }
    }

    fun cancelAnim() {
        anim?.cancel()
        anim = null
    }

    override fun onDraw(c: Canvas) {
        if (progress <= 0f) return
        val w = width.toFloat()
        val h = height.toFloat()
        val bulge = (w - 10f * d) * progress + 2f * d

        c.save()
        if (!onRight) c.scale(-1f, 1f, w / 2f, 0f)

        path.reset()
        path.moveTo(w, 0f)
        path.cubicTo(w - bulge * 0.1f, h * 0.28f, w - bulge, h * 0.30f, w - bulge, h * 0.5f)
        path.cubicTo(w - bulge, h * 0.70f, w - bulge * 0.1f, h * 0.72f, w, h)
        path.close()
        c.drawPath(path, sheetPaint)
        c.drawPath(path, rimPaint)

        gripPaint.alpha = (255 * (0.55f + 0.45f * progress)).toInt()
        val cx = w - bulge * 0.55f
        val cy = h / 2f
        val s = 5f * d
        c.drawLine(cx + s * 0.5f, cy - s, cx - s * 0.5f, cy, gripPaint)
        c.drawLine(cx - s * 0.5f, cy, cx + s * 0.5f, cy + s, gripPaint)
        c.restore()
    }
}
