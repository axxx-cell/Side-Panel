package com.axxxcell.sidepanel

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns

/** Pinned files and folders shown in the panel's File Dock. */
object FileDock {
    class Item(val uri: String, val name: String, val folder: Boolean)

    private const val PREFS = "filedock"
    private const val KEY = "items"

    fun load(ctx: Context): MutableList<Item> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
        return raw.split("\n").mapNotNull {
            val p = it.split("\t")
            if (p.size == 3) Item(p[1], p[2], p[0] == "D") else null
        }.toMutableList()
    }

    fun save(ctx: Context, items: List<Item>) {
        val raw = items.joinToString("\n") {
            (if (it.folder) "D" else "F") + "\t" + it.uri + "\t" + it.name.replace('\t', ' ').replace('\n', ' ')
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, raw).apply()
    }

    fun add(ctx: Context, item: Item) {
        val items = load(ctx)
        if (items.none { it.uri == item.uri }) {
            items.add(item)
            save(ctx, items)
        }
    }

    fun pick(ctx: Context, folder: Boolean) {
        ctx.startActivity(
            Intent(ctx, FilePickActivity::class.java)
                .putExtra("folder", folder)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

/** Invisible activity that shows the system file picker and pins what you choose. */
class FilePickActivity : Activity() {
    private var folder = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        folder = intent.getBooleanExtra("folder", false)
        if (savedInstanceState != null) return
        val i = if (folder) {
            Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        } else {
            Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*")
                .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        i.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
        runCatching { startActivityForResult(i, 1) }.onFailure { finish() }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && data != null) {
            val uris = mutableListOf<Uri>()
            data.data?.let { uris.add(it) }
            data.clipData?.let { c -> for (n in 0 until c.itemCount) uris.add(c.getItemAt(n).uri) }
            uris.distinct().forEach { u ->
                runCatching {
                    contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                FileDock.add(this, FileDock.Item(u.toString(), nameOf(u), folder))
            }
        }
        finish()
    }

    private fun nameOf(u: Uri): String {
        val doc = if (folder) {
            runCatching {
                DocumentsContract.buildDocumentUriUsingTree(u, DocumentsContract.getTreeDocumentId(u))
            }.getOrDefault(u)
        } else u
        return runCatching {
            contentResolver.query(doc, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull() ?: (u.lastPathSegment ?: "Item")
    }
}
