package com.example.sidepanel

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

object SetupGuides {

    private class Guide(val title: String, val body: String)

    private val guides = mapOf(
        "overlay" to Guide(
            "Display over other apps",
            "This lets the arrow and the panel appear on top of other apps.\n\n" +
                "1. Tap the step. A list of settings opens.\n" +
                "2. Turn on \"Allow display over other apps\" for Side Panel.\n" +
                "3. Press the back button to return here. The dot turns green."
        ),
        "accessibility" to Guide(
            "Screenshots and back arrow",
            "This is needed for the screenshot button and the back arrow.\n\n" +
                "1. Tap the step to open Accessibility settings.\n" +
                "2. Open \"Installed apps\" or \"Downloaded apps\" and tap Side Panel.\n" +
                "3. Turn the switch on. If a message says \"Restricted setting\", tap OK.\n\n" +
                "If the switch stays greyed out (restricted):\n" +
                "4. Tap \"Open app info\" below.\n" +
                "5. Tap the three dots at the top right.\n" +
                "6. Tap \"Allow restricted settings\" and confirm with your PIN or fingerprint.\n" +
                "7. Go back to Accessibility > Side Panel and turn it on, then tap Allow.\n\n" +
                "If you don't see the three dots, first do step 3 and tap OK on the restricted message, then come back to App info."
        ),
        "battery" to Guide(
            "Keep running in background",
            "This stops Android from closing the panel to save battery.\n\n" +
                "1. Tap the step.\n" +
                "2. Tap Allow (or choose Unrestricted / Don't optimize).\n" +
                "3. If the arrow still disappears, open your phone's Settings > Battery or Auto-start and allow Side Panel there."
        ),
        "enterkey" to Guide(
            "Enter key",
            "1. Tap Donate and send your donation.\n" +
                "2. Send your Device code with it.\n" +
                "3. You will get a key back. Tap Enter key, paste it, then tap Activate.\n\n" +
                "Pro turns on right away."
        ),
        "devicecode" to Guide(
            "Device code",
            "Tap the code to copy it. Send it when you donate so your key is made for this phone. One key works on one device."
        )
    )

    fun show(ctx: Context, key: String) {
        val g = guides[key] ?: return
        val b = AlertDialog.Builder(ctx)
            .setTitle(g.title)
            .setMessage(g.body)
            .setPositiveButton("Got it", null)
        if (key == "accessibility") {
            b.setNeutralButton("Open app info") { _, _ ->
                ctx.startActivity(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:${ctx.packageName}")
                    )
                )
            }
        }
        b.show()
    }

    /** Small round "?" button that opens the guide for [key]. */
    fun helpButton(ctx: Context, key: String): TextView {
        val d = ctx.resources.displayMetrics.density
        return TextView(ctx).apply {
            text = "?"
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            val size = (30 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(size, size).apply { marginEnd = (8 * d).toInt() }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF4285F4.toInt())
            }
            setOnClickListener { show(ctx, key) }
        }
    }
}
