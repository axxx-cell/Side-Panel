package com.example.sidepanel

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ResolveInfo
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class PanelService : Service() {

    companion object {
        const val HOLD_MS = 1200L          // how long to hold the arrow (1.2 s)
        const val PREFS = "panel"
        const val KEY_FAVS = "favs"
        const val KEY_ZONE = "zone"        // "full" or "middle"
        const val KEY_COOLER = "cooler"    // package name of the user's cooling app
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var edge: View? = null
    private var arrow: TextView? = null
    private var scrim: View? = null
    private var panel: FrameLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelLarge = false

    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    private val apps: List<ResolveInfo> by lazy {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        addEdge()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        edge?.let { runCatching { wm.removeView(it) } }
        arrow?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        scrim?.let { runCatching { wm.removeView(it) } }
        edge = null
        arrow = null
        panel = null
        scrim = null
        panelLp = null
        super.onDestroy()
    }

    // ---------- Service plumbing ----------

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("panel", "Side Panel", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "panel")
            .setContentTitle("Side Panel is running")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- Invisible edge strip: swipe in, arrow pops, hold to open ----------

    private fun addEdge() {
        val dm = resources.displayMetrics
        val middleOnly = prefs.getString(KEY_ZONE, "full") == "middle"
        val h = if (middleOnly) (dm.heightPixels * 0.5).toInt() else MATCH_PARENT

        val v = View(this)
        var state = 0          // 0 = idle, 1 = arrow showing, 2 = panel opened
        var startX = 0f

        val openPanel = Runnable {
            if (state == 1) {
                state = 2
                hideArrow()
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                showPanel()
            }
        }

        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    state = 0
                    startX = e.rawX
                }
                MotionEvent.ACTION_MOVE -> {
                    if (state == 0 && startX - e.rawX > dp(24)) {
                        state = 1
                        showArrow(e.rawY)
                        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        handler.postDelayed(openPanel, HOLD_MS)
                    } else if (state == 1) {
                        moveArrow(e.rawY)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(openPanel)
                    hideArrow()
                    state = 0
                }
            }
            true
        }

        val lp = WindowManager.LayoutParams(
            dp(14), h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        wm.addView(v, lp)
        edge = v
    }

    private fun showArrow(rawY: Float) {
        if (arrow != null) return
        val size = dp(48)
        val top = (rawY - size / 2).toInt()
        val a = TextView(this).apply {
            text = "‹"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF4285F4.toInt())
            }
            alpha = 0.4f
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.TOP
            x = dp(8)
            this.y = top
        }
        wm.addView(a, lp)
        a.animate().alpha(1f).setDuration(HOLD_MS).start()
        arrow = a
    }

    private fun moveArrow(rawY: Float) {
        val a = arrow ?: return
        val lp = a.layoutParams as WindowManager.LayoutParams
        lp.y = (rawY - dp(48) / 2).toInt()
        runCatching { wm.updateViewLayout(a, lp) }
    }

    private fun hideArrow() {
        arrow?.let {
            it.animate().cancel()
            runCatching { wm.removeView(it) }
        }
        arrow = null
    }

    // ---------- Panel: one line of icons, swipe on to Calculator, then Notes ----------

    private fun panelW() = (resources.displayMetrics.widthPixels * 0.94).toInt().coerceAtMost(dp(420))
    private fun smallH() = dp(104)
    private fun largeH() = (resources.displayMetrics.heightPixels * 0.6).toInt()

    private fun showPanel() {
        if (panel != null) return

        // Invisible full-screen layer behind the panel: tapping it closes the panel
        val s = View(this).apply {
            setBackgroundColor(0x22000000)
            setOnClickListener { hidePanel() }
        }
        wm.addView(
            s,
            WindowManager.LayoutParams(
                MATCH_PARENT, MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
        )
        scrim = s

        val root = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(0xFA202124.toInt())
                cornerRadius = dp(16).toFloat()
            }
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        val lp = WindowManager.LayoutParams(
            panelW(), smallH(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        wm.addView(root, lp)
        panel = root
        panelLp = lp
        panelLarge = false
        showStrip()
    }

    private fun setSize(large: Boolean) {
        val p = panel ?: return
        val lp = panelLp ?: return
        if (panelLarge == large) return
        panelLarge = large
        lp.height = if (large) largeH() else smallH()
        runCatching { wm.updateViewLayout(p, lp) }
    }

    private fun hidePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        scrim?.let { runCatching { wm.removeView(it) } }
        panel = null
        scrim = null
        panelLp = null
        panelLarge = false
    }

    private fun launch(pkg: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
            hidePanel()
        }
    }

    /** The main view: [tools + favorite apps] in one line, then Calculator, then Notes. */
    private fun showStrip() {
        val box = panel ?: return
        box.removeAllViews()
        setSize(false)

        val innerW = panelW() - dp(12)
        val cellW = dp(64)
        var iconsW = innerW
        var scroller: HorizontalScrollView? = null

        val byPkg = apps.associateBy { it.activityInfo.packageName }
        val favApps = loadFavs().mapNotNull { byPkg[it] }

        val cells = mutableListOf<View>()
        cells.add(cell(emojiIcon("🔄"), "Refresh", { doRefresh() }))
        cells.add(cell(emojiIcon("📸"), "Screenshot", { doScreenshot() }))
        cells.add(cell(emojiIcon("❄️"), coolLabel(), { coolDown() }, { showCoolerPicker() }))
        favApps.forEach { info ->
            val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(packageManager)) }
            cells.add(
                cell(icon, info.loadLabel(packageManager).toString(), {
                    launch(info.activityInfo.packageName)
                })
            )
        }
        cells.add(cell(emojiIcon("✏️"), "Edit apps", { showPicker() }))
        cells.add(cell(emojiIcon("🧮"), "Calc", { scroller?.smoothScrollTo(iconsW, 0) }))
        cells.add(cell(emojiIcon("📝"), "Notes", { scroller?.smoothScrollTo(iconsW + innerW, 0) }))

        iconsW = maxOf(cells.size * cellW, innerW)

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        cells.forEach { row.addView(it, LinearLayout.LayoutParams(cellW, WRAP_CONTENT)) }

        val strip = LinearLayout(this)
        strip.addView(row, LinearLayout.LayoutParams(iconsW, MATCH_PARENT))
        strip.addView(buildCalcView(), LinearLayout.LayoutParams(innerW, MATCH_PARENT))
        strip.addView(buildNotesView(), LinearLayout.LayoutParams(innerW, MATCH_PARENT))

        var touching = false

        // After a swipe ends, settle neatly on the end of the icons, Calculator, or Notes
        val snap = Runnable {
            val sc = scroller
            if (sc != null && !touching) {
                val x = sc.scrollX
                val lastFree = iconsW - innerW
                if (x > lastFree) {
                    val target = listOf(lastFree, iconsW, iconsW + innerW).minByOrNull { abs(it - x) }!!
                    if (abs(target - x) > 2) sc.smoothScrollTo(target, 0)
                }
            }
        }

        val sv = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(strip, FrameLayout.LayoutParams(WRAP_CONTENT, MATCH_PARENT))
            setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> touching = true
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        touching = false
                        handler.postDelayed(snap, 150)
                    }
                }
                false
            }
            setOnScrollChangeListener { _, x, _, _, _ ->
                // Grow the panel when you reach Calculator / Notes, shrink back on the icon line
                setSize(x > iconsW - innerW + dp(30))
                handler.removeCallbacks(snap)
                handler.postDelayed(snap, 150)
            }
        }
        scroller = sv
        box.addView(sv)
    }

    // ---------- Cells in the icon line ----------

    private fun emojiIcon(emoji: String): View = TextView(this).apply {
        text = emoji
        textSize = 22f
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xFF3C4043.toInt())
        }
    }

    private fun cell(
        icon: View,
        label: String,
        onClick: () -> Unit,
        onLong: (() -> Unit)? = null
    ): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(2), dp(6), dp(2), dp(4))
        addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)))
        addView(TextView(context).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 10f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
        })
        setOnClickListener { onClick() }
        if (onLong != null) {
            setOnLongClickListener { onLong.invoke(); true }
        }
    }

    // ---------- Tools ----------

    private fun coolLabel(): String {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        return if (t > 0) "Cool ${t / 10}°C" else "Cool"
    }

    private fun doRefresh() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        fun avail(): Long {
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            return mi.availMem
        }
        val home = packageManager
            .resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            ?.activityInfo?.packageName
        val before = avail()
        apps.map { it.activityInfo.packageName }
            .filter { it != home }
            .forEach { am.killBackgroundProcesses(it) }
        toast("Refreshing…")
        handler.postDelayed({
            val freedMb = (avail() - before) / (1024 * 1024)
            toast(if (freedMb > 0) "Freed about $freedMb MB" else "Done. Nothing much to free.")
        }, 800)
    }

    private fun doScreenshot() {
        val svc = ScreenshotService.instance
        hidePanel()   // so the panel isn't in the screenshot
        if (svc == null) {
            toast("Turn on Side Panel in Accessibility settings first")
            startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        handler.postDelayed({ svc.takeShot() }, 500)
    }

    private fun coolDown() {
        val pkg = prefs.getString(KEY_COOLER, null)
        if (pkg == null || packageManager.getLaunchIntentForPackage(pkg) == null) {
            showCoolerPicker()
        } else {
            launch(pkg)
        }
    }

    // ---------- Pickers (favorites, cooling app) ----------

    private fun loadFavs(): MutableList<String> =
        (prefs.getString(KEY_FAVS, "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()

    private fun saveFavs(list: List<String>) {
        prefs.edit().putString(KEY_FAVS, list.joinToString(",")).apply()
    }

    private fun appRow(info: ResolveInfo, trailing: View? = null): LinearLayout =
        LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            addView(ImageView(context).apply {
                setImageDrawable(info.loadIcon(packageManager))
            }, LinearLayout.LayoutParams(dp(32), dp(32)))
            addView(TextView(context).apply {
                text = info.loadLabel(packageManager)
                setTextColor(Color.WHITE)
                textSize = 15f
                setPadding(dp(12), 0, 0, 0)
            }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            if (trailing != null) addView(trailing)
        }

    private fun showPicker() {
        val box = panel ?: return
        setSize(true)
        box.removeAllViews()
        val selected = LinkedHashSet(loadFavs())

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(
            TextView(this).apply {
                text = "Tap apps to pick favorites"
                setTextColor(Color.WHITE)
                textSize = 14f
                setPadding(dp(8), 0, 0, 0)
            },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        )
        header.addView(Button(this).apply {
            text = "Done"
            isAllCaps = false
            setOnClickListener {
                saveFavs(selected.toList())
                showStrip()
            }
        })
        col.addView(header)

        val list = ListView(this).apply {
            divider = null
            adapter = object : BaseAdapter() {
                override fun getCount() = apps.size
                override fun getItem(position: Int): Any = apps[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                    val info = apps[position]
                    val cb = CheckBox(this@PanelService).apply {
                        isChecked = selected.contains(info.activityInfo.packageName)
                        isClickable = false
                        isFocusable = false
                        buttonTintList = ColorStateList.valueOf(Color.WHITE)
                    }
                    return appRow(info, cb).apply { tag = cb }
                }
            }
            setOnItemClickListener { _, row, position, _ ->
                val pkg = apps[position].activityInfo.packageName
                if (!selected.remove(pkg)) selected.add(pkg)
                (row.tag as CheckBox).isChecked = selected.contains(pkg)
            }
        }
        col.addView(list, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        box.addView(col)
    }

    private fun showCoolerPicker() {
        val box = panel ?: return
        setSize(true)
        box.removeAllViews()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = "Pick your cooling app"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(dp(8), dp(8), dp(8), dp(8))
        })
        val list = ListView(this).apply {
            divider = null
            adapter = object : BaseAdapter() {
                override fun getCount() = apps.size
                override fun getItem(position: Int): Any = apps[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View =
                    appRow(apps[position])
            }
            setOnItemClickListener { _, _, position, _ ->
                prefs.edit().putString(KEY_COOLER, apps[position].activityInfo.packageName).apply()
                showStrip()
            }
        }
        col.addView(list, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        box.addView(col)
    }

    // ---------- Notes page ----------

    private fun buildNotesView(): View {
        return EditText(this).apply {
            hint = "Quick notes…"
            setHintTextColor(0xFF9AA0A6.toInt())
            setTextColor(Color.WHITE)
            gravity = Gravity.TOP or Gravity.START
            setText(prefs.getString("notes", ""))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    prefs.edit().putString("notes", s.toString()).apply()
                }
            })
        }
    }

    // ---------- Calculator page ----------

    private fun buildCalcView(): View {
        var expr = ""
        val display = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 28f
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            text = "0"
        }

        val keys = listOf(
            "7", "8", "9", "÷",
            "4", "5", "6", "×",
            "1", "2", "3", "−",
            "0", ".", "C", "+",
            "(", ")", "⌫", "="
        )
        val grid = GridLayout(this).apply { columnCount = 4; rowCount = 5 }

        keys.forEachIndexed { i, key ->
            val b = Button(this).apply {
                text = key
                isAllCaps = false
                setOnClickListener {
                    when (key) {
                        "C" -> expr = ""
                        "⌫" -> expr = expr.dropLast(1)
                        "=" -> expr = Calculator.evaluate(expr)
                        else -> expr += key
                    }
                    display.text = expr.ifEmpty { "0" }
                }
            }
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(i / 4, 1f),
                GridLayout.spec(i % 4, 1f)
            ).apply { width = 0; height = 0 }
            grid.addView(b, lp)
        }

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(display, LinearLayout.LayoutParams(MATCH_PARENT, dp(64)))
            addView(grid, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        }
    }
}
