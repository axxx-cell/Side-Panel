package com.example.sidepanel

import android.animation.ValueAnimator
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.app.ActivityManager
import android.app.ActivityOptions
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ResolveInfo
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class PanelService : Service() {

    companion object {
        const val HOLD_MS = 500L           // how long to hold the arrow (0.5 s)
        const val PREFS = "panel"
        const val KEY_FAVS = "favs"
        const val KEY_ZONE = "zone"        // "full" or "middle"
        const val KEY_MODE = "mode"        // "small" window, "split" screen or "full" screen
        const val KEY_EDGE = "edge"        // "thin", "normal" or "wide"
        const val KEY_AUTOSTART = "autostart"

        @Volatile var running = false

        /** True only when "Enable freeform windows" is switched on in Developer options. */
        fun freeformOn(ctx: Context): Boolean =
            Settings.Global.getInt(ctx.contentResolver, "enable_freeform_support", 0) == 1

        fun forceResizableOn(ctx: Context): Boolean =
            Settings.Global.getInt(ctx.contentResolver, "force_resizable_activities", 0) == 1

        fun mode(ctx: Context): String =
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_MODE, "split") ?: "split"
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var edge: View? = null
    private var arrow: PullHandleView? = null
    private var scrim: View? = null
    private var panel: LinearLayout? = null
    private var panelBody: FrameLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelLarge = false

    // Controls shown after opening an app
    private var winCtl: View? = null
    private var backCtl: View? = null
    private var ctlPkg: String? = null
    private var ctlKind = "full"
    private var torchOn = false
    private var torchCb: CameraManager.TorchCallback? = null
    private var prevPkg: String? = null
    private var ctlShownAt = 0L

    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    private val apps: List<ResolveInfo> by lazy {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        addEdge()
        running = true

        // Keep the flashlight button in step with the real flashlight
        runCatching {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val cb = object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    torchOn = enabled
                }
            }
            cm.registerTorchCallback(cb, handler)
            torchCb = cb
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        torchCb?.let { cb ->
            runCatching { (getSystemService(CAMERA_SERVICE) as CameraManager).unregisterTorchCallback(cb) }
        }
        handler.removeCallbacksAndMessages(null)
        ScreenshotService.listener = null
        edge?.let { runCatching { wm.removeView(it) } }
        arrow?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        scrim?.let { runCatching { wm.removeView(it) } }
        winCtl?.let { runCatching { wm.removeView(it) } }
        backCtl?.let { runCatching { wm.removeView(it) } }
        edge = null; arrow = null; panel = null; scrim = null
        winCtl = null; backCtl = null; panelLp = null
        super.onDestroy()
    }

    // ---------- Service plumbing ----------

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("panel", "Side Panel", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "panel")
            .setContentTitle("Side Panel is running")
            .setSmallIcon(R.drawable.ic_window)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun homePkg(): String? = packageManager
        .resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
        ?.activityInfo?.packageName

    private fun edgeWidth() = when (prefs.getString(KEY_EDGE, "normal")) {
        "thin" -> dp(14)
        "wide" -> dp(36)
        else -> dp(24)
    }

    // ---------- Invisible edge strip: swipe in, arrow pops, hold to open ----------

    private fun addEdge() {
        val dm = resources.displayMetrics
        val middleOnly = prefs.getString(KEY_ZONE, "full") == "middle"
        val h = if (middleOnly) (dm.heightPixels * 0.5).toInt() else MATCH_PARENT

        val v = View(this)
        var state = 0          // 0 = idle, 1 = arrow showing, 2 = panel opened
        var startX = 0f
        var lastY = 0f

        val openPanel = Runnable {
            if (state == 1) {
                state = 2
                hideArrow()
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                runCatching { showPanel(lastY) }.onFailure {
                    hidePanel()
                    toast("Couldn't open the panel. Tap Restart in the Side Panel app.")
                }
            }
        }

        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    state = 0
                    startX = e.rawX
                    lastY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    lastY = e.rawY
                    if (state == 0 && startX - e.rawX > dp(16)) {
                        state = 1
                        showArrow(e.rawY)
                        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        handler.postDelayed(openPanel, HOLD_MS)
                    } else if (state == 1) {
                        moveArrow(e.rawY)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(openPanel)
                    hideArrow()
                    state = 0
                }
            }
            true
        }

        val lp = WindowManager.LayoutParams(
            edgeWidth(), h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        wm.addView(v, lp)
        edge = v
    }

    private fun showArrow(rawY: Float) {
        if (arrow != null) return
        val w = dp(44)
        val h = dp(170)
        val a = PullHandleView(this, true)
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.TOP
            x = 0
            this.y = (rawY - h / 2).toInt()
        }
        wm.addView(a, lp)
        a.setProgress(0.15f)
        a.animateHold(HOLD_MS) {}
        arrow = a
    }

    private fun moveArrow(rawY: Float) {
        val a = arrow ?: return
        val lp = a.layoutParams as WindowManager.LayoutParams
        lp.y = (rawY - lp.height / 2).toInt()
        runCatching { wm.updateViewLayout(a, lp) }
    }

    private fun hideArrow() {
        arrow?.let {
            it.cancelAnim()
            runCatching { wm.removeView(it) }
        }
        arrow = null
    }

    // ---------- Panel: apps column + tools column; swipe on to Calculator, then Notes ----------

    private fun smallW() = dp(148)
    private fun largeW() = (resources.displayMetrics.widthPixels * 0.85).toInt().coerceAtMost(dp(340))
    private fun panelH() = (resources.displayMetrics.heightPixels * 0.55).toInt()

    private fun showPanel(anchorY: Float) {
        if (panel != null) return
        clearControls()
        prevPkg = ScreenshotService.lastApp

        // Invisible full-screen layer behind the panel: tapping it closes the panel
        val s = View(this).apply {
            setBackgroundColor(0x22000000)
            setOnClickListener { hidePanel() }
        }
        wm.addView(
            s,
            WindowManager.LayoutParams(
                MATCH_PARENT, MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
        )
        scrim = s

        val dm = resources.displayMetrics
        val h = panelH()
        val maxOff = ((dm.heightPixels - h) / 2).coerceAtLeast(0)
        val yOff = (anchorY - dm.heightPixels / 2f).toInt().coerceIn(-maxOff, maxOff)

        val lp = WindowManager.LayoutParams(
            smallW(), h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            y = yOff
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(0xFA202124.toInt())
                cornerRadius = dp(16).toFloat()
            }
            setPadding(dp(6), dp(2), dp(6), dp(6))
        }

        // Grab bar: drag it up or down to move the panel
        val grip = FrameLayout(this)
        grip.addView(
            View(this).apply {
                background = GradientDrawable().apply {
                    setColor(0xFF5F6368.toInt())
                    cornerRadius = dp(2).toFloat()
                }
            },
            FrameLayout.LayoutParams(dp(36), dp(4), Gravity.CENTER)
        )
        var downY = 0f
        var startOff = 0
        grip.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = e.rawY
                    startOff = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    val limit = ((dm.heightPixels - lp.height) / 2).coerceAtLeast(0)
                    lp.y = (startOff + (e.rawY - downY)).toInt().coerceIn(-limit, limit)
                    runCatching { wm.updateViewLayout(root, lp) }
                }
            }
            true
        }
        root.addView(grip, LinearLayout.LayoutParams(MATCH_PARENT, dp(22)))

        val body = FrameLayout(this)
        root.addView(body, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        wm.addView(root, lp)
        panel = root
        panelBody = body
        panelLp = lp
        panelLarge = false
        showStrip()
    }

    /** Narrow for the apps/tools page, wider for Calculator, Notes and pickers. */
    private fun setWide(wide: Boolean) {
        val p = panel ?: return
        val lp = panelLp ?: return
        if (panelLarge == wide) return
        panelLarge = wide
        lp.width = if (wide) largeW() else smallW()
        runCatching { wm.updateViewLayout(p, lp) }
    }

    private fun hidePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        scrim?.let { runCatching { wm.removeView(it) } }
        panel = null
        panelBody = null
        scrim = null
        panelLp = null
        panelLarge = false
    }

    private fun verticalScroll(col: LinearLayout): View = ScrollView(this).apply {
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        addView(col)
    }

    /** Page 1: favorite apps (one column) next to tools (one column). Swipe on: Calculator, Notes. */
    private fun showStrip() {
        val box = panelBody ?: return
        box.removeAllViews()
        setWide(false)

        val smallInner = smallW() - dp(12)
        val largeInner = largeW() - dp(12)

        val byPkg = apps.associateBy { it.activityInfo.packageName }
        val favApps = loadFavs().mapNotNull { byPkg[it] }

        // Column 1: favorite apps
        val appsCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (favApps.isEmpty()) {
            appsCol.addView(TextView(this).apply {
                text = "No favorites yet.\nTap Edit apps."
                setTextColor(0xFF9AA0A6.toInt())
                textSize = 11f
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(16), dp(4), 0)
            })
        }
        favApps.forEach { info ->
            val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(packageManager)) }
            appsCol.addView(
                cell(icon, info.loadLabel(packageManager).toString(), {
                    openApp(info.activityInfo.packageName)
                }),
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
            )
        }

        // Column 2: tools
        val refreshIcon = toolIcon(R.drawable.ic_refresh)
        var refreshLabel: TextView? = null
        val refreshCell = cell(refreshIcon, "Refresh", { doRefresh(refreshIcon, refreshLabel) })
        refreshLabel = refreshCell.getChildAt(1) as TextView

        val coolIcon = toolIcon(R.drawable.ic_snow)
        coolIcon.setBackgroundColor(0)  // replaced just below with the round background
        coolIcon.background = roundBg(tempColor())
        var coolLabelView: TextView? = null
        val coolCell = cell(coolIcon, coolLabel(), { doCoolDown(coolIcon, coolLabelView) })
        coolLabelView = coolCell.getChildAt(1) as TextView

        val winIcon = toolIcon(modeIcon())
        var winLabel: TextView? = null
        val winCell = cell(winIcon, modeLabel(), { toggleMode(winIcon, winLabel) })
        winLabel = winCell.getChildAt(1) as TextView

        val torchIcon = toolIcon(R.drawable.ic_flashlight)
        (torchIcon.background as? GradientDrawable)
            ?.setColor(if (torchOn) 0xFFFBBC04.toInt() else 0xFF3C4043.toInt())
        var torchLabel: TextView? = null
        val torchCell = cell(torchIcon, if (torchOn) "Light on" else "Flashlight", {
            toggleTorch(torchIcon, torchLabel)
        })
        torchLabel = torchCell.getChildAt(1) as TextView

        val toolsCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf(
            refreshCell,
            cell(toolIcon(R.drawable.ic_screenshot), "Screenshot", { doScreenshot() }),
            coolCell,
            torchCell,
            cell(toolIcon(R.drawable.ic_volume), "Volume", { openVolume() }),
            cell(toolIcon(R.drawable.ic_wifi), "Internet", { openInternet() }),
            winCell,
            cell(toolIcon(R.drawable.ic_edit), "Edit apps", { showPicker() })
        ).forEach { toolsCol.addView(it, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)) }

        val page1 = LinearLayout(this)
        page1.addView(verticalScroll(appsCol), LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))
        page1.addView(
            View(this).apply { setBackgroundColor(0x33FFFFFF) },
            LinearLayout.LayoutParams(dp(1), MATCH_PARENT)
        )
        page1.addView(verticalScroll(toolsCol), LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))

        val strip = LinearLayout(this)
        strip.addView(page1, LinearLayout.LayoutParams(smallInner, MATCH_PARENT))
        strip.addView(buildCalcView(), LinearLayout.LayoutParams(largeInner, MATCH_PARENT))
        strip.addView(buildNotesView(), LinearLayout.LayoutParams(largeInner, MATCH_PARENT))

        val stops = listOf(0, smallInner, smallInner + largeInner)
        fun pageOf(x: Int): Int = stops.indices.minByOrNull { abs(stops[it] - x) } ?: 0

        val sv = NoFlingScrollView(this)
        sv.isHorizontalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.addView(strip, FrameLayout.LayoutParams(WRAP_CONTENT, MATCH_PARENT))

        val dotViews = (0..2).map {
            TextView(this).apply {
                text = "●"
                textSize = 11f
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(4), dp(10), dp(4))
            }
        }
        fun showDots(i: Int) {
            dotViews.forEachIndexed { n, d ->
                d.setTextColor(if (n == i) Color.WHITE else 0xFF5F6368.toInt())
            }
        }
        showDots(0)

        // Always lands on exactly one page. Widen first when going on, shrink first when going back.
        fun goToPage(i: Int) {
            setWide(i > 0)
            showDots(i)
            sv.smoothScrollTo(stops[i], 0)
        }
        dotViews.forEachIndexed { i, d -> d.setOnClickListener { goToPage(i) } }

        var startPage = 0
        var startX = 0
        sv.onDown = {
            startX = sv.scrollX
            startPage = pageOf(startX)
        }
        sv.onRelease = release@{
            val moved = sv.scrollX - startX
            if (moved == 0) return@release       // a tap, not a swipe
            var target = startPage
            if (moved > 0 && startPage < 2) {
                val need = maxOf(dp(24), ((stops[startPage + 1] - stops[startPage]) * 0.2f).toInt())
                if (moved >= need) target = startPage + 1
            } else if (moved < 0 && startPage > 0) {
                val need = maxOf(dp(24), ((stops[startPage] - stops[startPage - 1]) * 0.2f).toInt())
                if (-moved >= need) target = startPage - 1
            }
            goToPage(target)
        }
        sv.setOnScrollChangeListener { _, x, _, _, _ -> showDots(pageOf(x)) }

        val dotsRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        dotViews.forEach { dotsRow.addView(it) }

        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wrap.addView(sv, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        wrap.addView(dotsRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        box.addView(wrap)
    }

    // ---------- Cells ----------

    private fun roundBg(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun toolIcon(res: Int): ImageView = ImageView(this).apply {
        setImageResource(res)
        setPadding(dp(11), dp(11), dp(11), dp(11))
        background = roundBg(0xFF3C4043.toInt())
    }

    private fun cell(
        icon: View,
        label: String,
        onClick: () -> Unit,
        onLong: (() -> Unit)? = null
    ): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(2), dp(6), dp(2), dp(4))
        addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)))
        addView(TextView(context).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 10f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
        })
        setOnClickListener { onClick() }
        if (onLong != null) {
            setOnLongClickListener { onLong.invoke(); true }
        }
    }

    private fun flashColor(icon: View, to: Int, base: Int, ms: Long) {
        ValueAnimator.ofArgb(base, to, base).apply {
            duration = ms
            addUpdateListener { a ->
                (icon.background as? GradientDrawable)?.setColor(a.animatedValue as Int)
            }
            start()
        }
    }

    // ---------- Opening apps: small window or full screen ----------

    private fun modeLabel() = when (mode(this)) {
        "small" -> "Small window"
        "split" -> "Split screen"
        else -> "Full screen"
    }

    private fun modeIcon() = when (mode(this)) {
        "small" -> R.drawable.ic_window
        "split" -> R.drawable.ic_split
        else -> R.drawable.ic_fullscreen
    }

    private fun toggleMode(icon: ImageView, label: TextView?) {
        val next = when (mode(this)) {
            "small" -> "split"
            "split" -> "full"
            else -> "small"
        }
        prefs.edit().putString(KEY_MODE, next).apply()
        icon.setImageResource(modeIcon())
        label?.text = modeLabel()
        if (next == "small" && !freeformOn(this)) {
            toast("Small windows need freeform windows turned on in Developer options.")
        }
        if (next == "split" && ScreenshotService.instance == null) {
            toast("Split screen needs the Accessibility setting turned on.")
        }
    }

    private fun smallBounds(): Rect {
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.8).toInt()
        val h = (dm.heightPixels * 0.42).toInt()
        val left = (dm.widthPixels - w) / 2
        val top = (dm.heightPixels * 0.3).toInt()
        return Rect(left, top, left + w, top + h)
    }

    private fun launchIntentFor(pkg: String): Intent? =
        packageManager.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    private fun openApp(pkg: String) {
        val intent = launchIntentFor(pkg) ?: return
        clearControls()
        hidePanel()
        ctlPkg = pkg

        when (mode(this)) {
            "small" -> {
                if (freeformOn(this)) {
                    ctlKind = "small"
                    val b = smallBounds()
                    startActivity(intent, ActivityOptions.makeBasic().setLaunchBounds(b).toBundle())
                    showWindowButtons(b)
                } else {
                    toast("Small windows need freeform windows turned on. Opening full screen.")
                    ctlKind = "full"
                    startActivity(intent)
                    showBackArrow()
                }
            }
            "split" -> openSplit(intent)
            else -> {
                ctlKind = "full"
                startActivity(intent)
                showBackArrow()
            }
        }
    }

    /** Keeps the app you were in on top and opens the chosen app below it. */
    private fun openSplit(intent: Intent) {
        val svc = ScreenshotService.instance
        if (svc == null || prevPkg == homePkg()) {
            toast(
                if (svc == null) "Split screen needs the Accessibility setting. Opening full screen."
                else "Open an app first, then split. Opening full screen."
            )
            ctlKind = "full"
            startActivity(intent)
            showBackArrow()
            return
        }
        ctlKind = "split"
        val already = svc.isSplit()          // don't toggle if the screen is already split
        if (!already) svc.splitScreen()
        handler.postDelayed({
            // launched from the accessibility service, which Android lets place windows in split screen
            if (!svc.openAdjacent(intent)) {
                runCatching { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)) }
            }
            val dm = resources.displayMetrics
            showWindowButtons(Rect(0, dm.heightPixels / 2 + dp(40), dm.widthPixels, dm.heightPixels))
        }, if (already) 150L else 900L)
    }

    private fun goFullScreen() {
        val pkg = ctlPkg ?: return
        val intent = launchIntentFor(pkg) ?: return
        removeView(winCtl); winCtl = null
        if (ctlKind == "split") {
            ScreenshotService.instance?.splitScreen()   // leave split screen
            handler.postDelayed({
                startActivity(intent)
                showBackArrow()
            }, 600)
            return
        }
        val dm = resources.displayMetrics
        val opts = ActivityOptions.makeBasic()
            .setLaunchBounds(Rect(0, 0, dm.widthPixels, dm.heightPixels))
        startActivity(intent, opts.toBundle())
        showBackArrow()
    }

    private fun goBack() {
        clearControls()
        val prev = prevPkg
        val back = if (prev == null || prev == homePkg()) null else launchIntentFor(prev)
        if (back != null) {
            startActivity(back)
        } else {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    private fun removeView(v: View?) {
        if (v != null) runCatching { wm.removeView(v) }
    }

    private fun clearControls() {
        removeView(winCtl); winCtl = null
        removeView(backCtl); backCtl = null
        ScreenshotService.listener = null
    }

    private fun addOverlay(v: View, w: Int, h: Int, g: Int, px: Int, py: Int): View {
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = g
            x = px
            this.y = py
        }
        wm.addView(v, lp)
        return v
    }

    private fun smallIconButton(res: Int, onClick: () -> Unit): ImageView = ImageView(this).apply {
        setImageResource(res)
        setPadding(dp(6), dp(6), dp(6), dp(6))
        setOnClickListener { onClick() }
    }

    /** Small buttons just above the small window: full screen, and hide these buttons. */
    private fun showWindowButtons(b: Rect) {
        val pill = LinearLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(0xEE202124.toInt())
                cornerRadius = dp(16).toFloat()
            }
            setPadding(dp(2), dp(2), dp(2), dp(2))
            addView(smallIconButton(R.drawable.ic_fullscreen) { goFullScreen() },
                LinearLayout.LayoutParams(dp(32), dp(32)))
            addView(smallIconButton(R.drawable.ic_close) { clearControls() },
                LinearLayout.LayoutParams(dp(32), dp(32)))
        }
        val px = (b.right - dp(68)).coerceAtLeast(0)
        val py = (b.top - dp(40)).coerceAtLeast(dp(24))
        winCtl = addOverlay(pill, WRAP_CONTENT, WRAP_CONTENT, Gravity.START or Gravity.TOP, px, py)
    }

    /** Small arrow on the left edge: tap to return to the app you were in before. */
    private fun showBackArrow() {
        val r = dp(16).toFloat()
        val v = ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setPadding(dp(3), dp(16), dp(3), dp(16))
            background = GradientDrawable().apply {
                setColor(0xEE202124.toInt())
                cornerRadii = floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
            }
            setOnClickListener { goBack() }
            setOnLongClickListener { clearControls(); true }   // long-press hides it
        }
        backCtl = addOverlay(v, dp(30), dp(64), Gravity.START or Gravity.CENTER_VERTICAL, 0, 0)

        // Hide the arrow if you get back to the earlier app (or home) by yourself
        ctlShownAt = SystemClock.uptimeMillis()
        val home = homePkg()
        ScreenshotService.listener = { pkg ->
            if (SystemClock.uptimeMillis() - ctlShownAt > 1500 && (pkg == prevPkg || pkg == home)) {
                handler.post { clearControls() }
            }
        }
    }

    // ---------- Tools ----------

    private fun batteryTempC(): Float? {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        return if (t > 0) t / 10f else null
    }

    private fun coolLabel(): String {
        val t = batteryTempC() ?: return "Cool down"
        return if (t >= 41f) "Hot ${t.toInt()}°C" else "Cool ${t.toInt()}°C"
    }

    private fun tempColor(): Int {
        val t = batteryTempC() ?: return 0xFF3C4043.toInt()
        return when {
            t >= 41f -> 0xFFE53935.toInt()
            t >= 38f -> 0xFFFB8C00.toInt()
            else -> 0xFF3C4043.toInt()
        }
    }

    private fun availMem(): Long {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.availMem
    }

    private fun killBackground() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val home = homePkg()
        apps.map { it.activityInfo.packageName }
            .filter { it != home && it != ctlPkg }
            .forEach { am.killBackgroundProcesses(it) }
    }

    /** Refresh: spins and swells, flashes green, then shows how much memory was freed. */
    private fun doRefresh(icon: ImageView, label: TextView?) {
        val before = availMem()
        killBackground()
        label?.text = "Cleaning…"
        icon.animate().cancel()
        icon.animate()
            .rotationBy(720f).scaleX(1.18f).scaleY(1.18f)
            .setDuration(1200)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .withEndAction { icon.rotation = 0f; icon.scaleX = 1f; icon.scaleY = 1f }
            .start()
        flashColor(icon, 0xFF34A853.toInt(), 0xFF3C4043.toInt(), 1400)
        handler.postDelayed({
            val freedMb = (availMem() - before) / (1024 * 1024)
            label?.text = if (freedMb > 0) "✓ $freedMb MB" else "✓ Clean"
            handler.postDelayed({ label?.text = "Refresh" }, 2500)
        }, 1300)
    }

    /**
     * Cool down (no other app needed): closes background apps so the phone does less work,
     * and shows the battery temperature. It can't cool the hardware directly.
     */
    private fun doCoolDown(icon: ImageView, label: TextView?) {
        killBackground()
        label?.text = "Cooling…"
        icon.animate().cancel()
        icon.animate()
            .rotationBy(360f)
            .setDuration(2500)
            .setInterpolator(LinearInterpolator())
            .withEndAction { icon.rotation = 0f }
            .start()
        flashColor(icon, 0xFF4FC3F7.toInt(), tempColor(), 2500)
        handler.postDelayed({
            val t = batteryTempC()
            label?.text = if (t != null) "✓ ${"%.1f".format(t)}°C" else "✓ Done"
            toast("Background apps closed. Heat drops slowly, so give it a few minutes.")
            handler.postDelayed({ label?.text = coolLabel() }, 3000)
        }, 2600)
    }

    private fun toggleTorch(icon: ImageView, label: TextView?) {
        val cm = getSystemService(CAMERA_SERVICE) as CameraManager
        val id = runCatching {
            cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        }.getOrNull()
        if (id == null) {
            toast("No flashlight found on this phone")
            return
        }
        val next = !torchOn
        val ok = runCatching { cm.setTorchMode(id, next) }.isSuccess
        if (!ok) {
            toast("Couldn't switch the flashlight")
            return
        }
        torchOn = next
        (icon.background as? GradientDrawable)
            ?.setColor(if (next) 0xFFFBBC04.toInt() else 0xFF3C4043.toInt())
        label?.text = if (next) "Light on" else "Flashlight"
    }

    /** Shows Android's own volume slider. */
    private fun openVolume() {
        hidePanel()
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI)
    }

    /** Opens Android's own Wi-Fi / mobile data quick panel. */
    private fun openInternet() {
        hidePanel()
        val action = if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY
        else Settings.ACTION_WIFI_SETTINGS
        startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun doScreenshot() {
        val svc = ScreenshotService.instance
        hidePanel()   // so the panel isn't in the screenshot
        if (svc == null) {
            toast("Turn on Side Panel in Accessibility settings first")
            startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        handler.postDelayed({ svc.takeShot() }, 500)
    }

    // ---------- Favorites picker ----------

    private fun loadFavs(): MutableList<String> =
        (prefs.getString(KEY_FAVS, "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()

    private fun saveFavs(list: List<String>) {
        prefs.edit().putString(KEY_FAVS, list.joinToString(",")).apply()
    }

    private fun appRow(info: ResolveInfo, trailing: View? = null): LinearLayout =
        LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            addView(ImageView(context).apply {
                setImageDrawable(info.loadIcon(packageManager))
            }, LinearLayout.LayoutParams(dp(32), dp(32)))
            addView(TextView(context).apply {
                text = info.loadLabel(packageManager)
                setTextColor(Color.WHITE)
                textSize = 15f
                setPadding(dp(12), 0, 0, 0)
            }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            if (trailing != null) addView(trailing)
        }

    private fun showPicker() {
        val box = panelBody ?: return
        setWide(true)
        box.removeAllViews()
        val selected = LinkedHashSet(loadFavs())

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(
            TextView(this).apply {
                text = "Tap apps to pick favorites"
                setTextColor(Color.WHITE)
                textSize = 14f
                setPadding(dp(8), 0, 0, 0)
            },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        )
        header.addView(Button(this).apply {
            text = "Done"
            isAllCaps = false
            setOnClickListener {
                saveFavs(selected.toList())
                showStrip()
            }
        })
        col.addView(header)

        val list = ListView(this).apply {
            divider = null
            adapter = object : BaseAdapter() {
                override fun getCount() = apps.size
                override fun getItem(position: Int): Any = apps[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                    val info = apps[position]
                    val cb = CheckBox(this@PanelService).apply {
                        isChecked = selected.contains(info.activityInfo.packageName)
                        isClickable = false
                        isFocusable = false
                        buttonTintList = ColorStateList.valueOf(Color.WHITE)
                    }
                    return appRow(info, cb).apply { tag = cb }
                }
            }
            setOnItemClickListener { _, row, position, _ ->
                val pkg = apps[position].activityInfo.packageName
                if (!selected.remove(pkg)) selected.add(pkg)
                (row.tag as CheckBox).isChecked = selected.contains(pkg)
            }
        }
        col.addView(list, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        box.addView(col)
    }

    // ---------- Notes page ----------

    private fun buildNotesView(): View {
        return EditText(this).apply {
            hint = "Quick notes…"
            setHintTextColor(0xFF9AA0A6.toInt())
            setTextColor(Color.WHITE)
            gravity = Gravity.TOP or Gravity.START
            setText(prefs.getString("notes", ""))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    prefs.edit().putString("notes", s.toString()).apply()
                }
            })
        }
    }

    // ---------- Calculator page ----------

    private fun buildCalcView(): View {
        var expr = ""
        val display = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 28f
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            text = "0"
        }

        val keys = listOf(
            "7", "8", "9", "÷",
            "4", "5", "6", "×",
            "1", "2", "3", "−",
            "0", ".", "C", "+",
            "(", ")", "⌫", "="
        )
        val grid = GridLayout(this).apply { columnCount = 4; rowCount = 5 }

        keys.forEachIndexed { i, key ->
            val b = Button(this).apply {
                text = key
                isAllCaps = false
                setOnClickListener {
                    when (key) {
                        "C" -> expr = ""
                        "⌫" -> expr = expr.dropLast(1)
                        "=" -> expr = Calculator.evaluate(expr)
                        else -> expr += key
                    }
                    display.text = expr.ifEmpty { "0" }
                }
            }
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(i / 4, 1f),
                GridLayout.spec(i % 4, 1f)
            ).apply { width = 0; height = 0 }
            grid.addView(b, lp)
        }

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(display, LinearLayout.LayoutParams(MATCH_PARENT, dp(64)))
            addView(grid, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        }
    }
}

/** Scroll view that never keeps gliding after you lift your finger, so one swipe = one page. */
private class NoFlingScrollView(ctx: Context) : HorizontalScrollView(ctx) {
    var onDown: (() -> Unit)? = null
    var onRelease: (() -> Unit)? = null

    override fun fling(velocityX: Int) {}

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) onDown?.invoke()
        val handled = super.dispatchTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
            onRelease?.invoke()
        }
        return handled
    }
}
