package com.example.sidepanel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ResolveInfo
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class PanelService : Service() {

    private lateinit var wm: WindowManager
    private var handle: View? = null
    private var panel: View? = null

    private val apps: List<ResolveInfo> by lazy {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        addHandle()
    }

    override fun onDestroy() {
        handle?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        handle = null
        panel = null
        super.onDestroy()
    }

    // ---------- Service plumbing ----------

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("panel", "Side Panel", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "panel")
            .setContentTitle("Side Panel is running")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- Edge handle ----------

    private fun addHandle() {
        val v = View(this).apply {
            background = GradientDrawable().apply {
                setColor(0xCC4285F4.toInt())
                cornerRadii = floatArrayOf(
                    dp(12).toFloat(), dp(12).toFloat(), 0f, 0f,
                    0f, 0f, dp(12).toFloat(), dp(12).toFloat()
                )
            }
            setOnClickListener { showPanel() }
        }
        val lp = WindowManager.LayoutParams(
            dp(20), dp(140),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        wm.addView(v, lp)
        handle = v
    }

    // ---------- Panel ----------

    private fun showPanel() {
        if (panel != null) return
        handle?.visibility = View.GONE

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(0xFA202124.toInt())
                cornerRadius = dp(16).toFloat()
            }
            setPadding(dp(8), dp(8), dp(8), dp(8))
            // Tapping outside the panel closes it
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_OUTSIDE) { hidePanel(); true } else false
            }
        }

        val content = FrameLayout(this)
        val appsView = buildAppsView()
        val notesView = buildNotesView()
        val calcView = buildCalcView()

        fun select(v: View) {
            content.removeAllViews()
            content.addView(v)
        }

        val tabs = LinearLayout(this)
        listOf("Apps" to appsView, "Notes" to notesView, "Calc" to calcView).forEach { (label, view) ->
            tabs.addView(
                Button(this).apply {
                    text = label
                    isAllCaps = false
                    setOnClickListener { select(view) }
                },
                LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
            )
        }
        tabs.addView(
            Button(this).apply {
                text = "✕"
                setOnClickListener { hidePanel() }
            },
            LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT)
        )

        root.addView(tabs)
        root.addView(content, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        select(appsView)

        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            (dm.widthPixels * 0.85).toInt().coerceAtMost(dp(360)),
            (dm.heightPixels * 0.7).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        wm.addView(root, lp)
        panel = root
    }

    private fun hidePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        handle?.visibility = View.VISIBLE
    }

    // ---------- Tab: Apps ----------

    private fun buildAppsView(): View {
        val adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(position: Int) = apps[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val info = apps[position]
                return LinearLayout(this@PanelService).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(dp(4), dp(8), dp(4), dp(8))
                    addView(ImageView(context).apply {
                        setImageDrawable(info.loadIcon(packageManager))
                    }, LinearLayout.LayoutParams(dp(44), dp(44)))
                    addView(TextView(context).apply {
                        text = info.loadLabel(packageManager)
                        setTextColor(Color.WHITE)
                        textSize = 11f
                        maxLines = 1
                        gravity = Gravity.CENTER
                    })
                }
            }
        }
        return GridView(this).apply {
            numColumns = 4
            this.adapter = adapter
            setOnItemClickListener { _, _, position, _ ->
                val pkg = apps[position].activityInfo.packageName
                packageManager.getLaunchIntentForPackage(pkg)?.let {
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    hidePanel()
                    startActivity(it)
                }
            }
        }
    }

    // ---------- Tab: Notes ----------

    private fun buildNotesView(): View {
        val prefs = getSharedPreferences("panel", MODE_PRIVATE)
        return EditText(this).apply {
            hint = "Quick notes…"
            setHintTextColor(0xFF9AA0A6.toInt())
            setTextColor(Color.WHITE)
            gravity = Gravity.TOP or Gravity.START
            setText(prefs.getString("notes", ""))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    prefs.edit().putString("notes", s.toString()).apply()
                }
            })
        }
    }

    // ---------- Tab: Calculator ----------

    private fun buildCalcView(): View {
        var expr = ""
        val display = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 28f
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            text = "0"
        }

        val keys = listOf(
            "7", "8", "9", "÷",
            "4", "5", "6", "×",
            "1", "2", "3", "−",
            "0", ".", "C", "+",
            "(", ")", "⌫", "="
        )
        val grid = GridLayout(this).apply { columnCount = 4; rowCount = 5 }

        keys.forEachIndexed { i, key ->
            val b = Button(this).apply {
                text = key
                isAllCaps = false
                setOnClickListener {
                    when (key) {
                        "C" -> expr = ""
                        "⌫" -> expr = expr.dropLast(1)
                        "=" -> expr = Calculator.evaluate(expr)
                        else -> expr += key
                    }
                    display.text = expr.ifEmpty { "0" }
                }
            }
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(i / 4, 1f),
                GridLayout.spec(i % 4, 1f)
            ).apply { width = 0; height = 0 }
            grid.addView(b, lp)
        }

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(display, LinearLayout.LayoutParams(MATCH_PARENT, dp(64)))
            addView(grid, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        }
    }
}
