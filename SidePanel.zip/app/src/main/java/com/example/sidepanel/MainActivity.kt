package com.example.sidepanel

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private var freeformText: TextView? = null

    private fun freeformStatus(): String =
        if (PanelService.freeformOn(this)) "Small windows: available"
        else "Small windows: OFF. Turn on \"Enable freeform windows\" in Developer options, then restart your phone."

    override fun onResume() {
        super.onResume()
        freeformText?.text = freeformStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(PanelService.PREFS, MODE_PRIVATE)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }

        layout.addView(TextView(this).apply {
            text = "Side Panel\nSwipe in from the right edge, then hold the arrow for half a second. " +
                "Swipe left for Calculator, then Notes. Tap outside to close."
            textSize = 18f
            gravity = Gravity.CENTER
        })

        layout.addView(Button(this).apply {
            text = "1. Allow display over other apps"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        })

        fun zoneLabel(): String =
            if (prefs.getString(PanelService.KEY_ZONE, "full") == "middle")
                "Edge zone: middle only (tap to change)"
            else
                "Edge zone: full height (tap to change)"

        layout.addView(Button(this).apply {
            text = zoneLabel()
            setOnClickListener {
                val next = if (prefs.getString(PanelService.KEY_ZONE, "full") == "middle") "full" else "middle"
                prefs.edit().putString(PanelService.KEY_ZONE, next).apply()
                text = zoneLabel()
            }
        })

        layout.addView(Button(this).apply {
            text = "2. Start / restart panel"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    text = "Grant permission in step 1 first"
                    return@setOnClickListener
                }
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                val svc = Intent(this@MainActivity, PanelService::class.java)
                stopService(svc)
                startForegroundService(svc)
            }
        })

        layout.addView(Button(this).apply {
            text = "3. Enable screenshots + back arrow (Accessibility)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        val status = TextView(this).apply {
            text = freeformStatus()
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, 0)
        }
        freeformText = status
        layout.addView(status)

        layout.addView(Button(this).apply {
            text = "4. Open Developer options (for small windows)"
            setOnClickListener {
                runCatching { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
                    .onFailure { startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)) }
            }
        })

        layout.addView(Button(this).apply {
            text = "Stop panel"
            setOnClickListener { stopService(Intent(this@MainActivity, PanelService::class.java)) }
        })

        setContentView(layout)
    }
}
