package com.example.sidepanel

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }

        layout.addView(TextView(this).apply {
            text = "Side Panel\nTap the edge handle on your screen to open it."
            textSize = 18f
            gravity = Gravity.CENTER
        })

        layout.addView(Button(this).apply {
            text = "1. Allow display over other apps"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        })

        layout.addView(Button(this).apply {
            text = "2. Start panel"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    text = "Grant permission in step 1 first"
                    return@setOnClickListener
                }
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                startForegroundService(Intent(this@MainActivity, PanelService::class.java))
            }
        })

        layout.addView(Button(this).apply {
            text = "Stop panel"
            setOnClickListener { stopService(Intent(this@MainActivity, PanelService::class.java)) }
        })

        setContentView(layout)
    }
}
