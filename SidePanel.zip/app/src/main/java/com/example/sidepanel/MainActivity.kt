package com.example.sidepanel

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val bg = 0xFF0F1115.toInt()
    private val cardBg = 0xFF1B1F27.toInt()
    private val accent = 0xFF4285F4.toInt()
    private val good = 0xFF34A853.toInt()
    private val bad = 0xFFEA4335.toInt()
    private val sub = 0xFF9AA0A6.toInt()

    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences(PanelService.PREFS, MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    // ---------- Building blocks ----------

    private fun card(title: String, highlight: Boolean = false, build: LinearLayout.() -> Unit) {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = if (highlight) GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF22305A.toInt(), 0xFF1B1F27.toInt())
            ).apply {
                cornerRadius = dp(16).toFloat()
                setStroke(dp(2), accent)
            } else rounded(cardBg, 16)
            setPadding(dp(16), dp(14), dp(16), dp(10))
        }
        val titleRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(6))
        }
        titleRow.addView(TextView(this).apply {
            text = title.uppercase()
            setTextColor(if (highlight) 0xFF8AB4F8.toInt() else sub)
            textSize = 12f
            if (highlight) setTypeface(typeface, Typeface.BOLD)
        })
        if (highlight) {
            titleRow.addView(TextView(this).apply {
                text = "PRO"
                setTextColor(Color.WHITE)
                textSize = 10f
                setTypeface(typeface, Typeface.BOLD)
                background = rounded(accent, 8)
                setPadding(dp(8), dp(2), dp(8), dp(2))
            }, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { marginStart = dp(8) })
        }
        c.addView(titleRow)
        c.build()
        root.addView(c, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(16) })
    }

    private fun row(title: String, subtitle: String, ok: Boolean?, help: String? = null, onClick: () -> Unit): View =
        LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
            val dot = View(context).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(
                        when (ok) {
                            true -> good
                            false -> bad
                            null -> 0xFF5F6368.toInt()
                        }
                    )
                }
            }
            addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)))
            val texts = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, dp(8), 0)
            }
            texts.addView(TextView(context).apply {
                text = title
                setTextColor(Color.WHITE)
                textSize = 15f
            })
            texts.addView(TextView(context).apply {
                text = subtitle
                setTextColor(sub)
                textSize = 12f
            })
            addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            if (help != null) addView(SetupGuides.helpButton(context, help))
            addView(TextView(context).apply {
                text = "›"
                setTextColor(sub)
                textSize = 22f
            })
            setOnClickListener { onClick() }
        }

    private fun bigButton(label: String, color: Int, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            background = rounded(color, 12)
            stateListAnimator = null
            setOnClickListener { onClick() }
        }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- Screen ----------

    private fun render() {
        root.removeAllViews()

        // Header
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(
            ImageView(this).apply { setImageResource(R.mipmap.ic_launcher) },
            LinearLayout.LayoutParams(dp(60), dp(60))
        )
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        titles.addView(TextView(this).apply {
            text = "Side Panel"
            setTextColor(Color.WHITE)
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
        })
        titles.addView(TextView(this).apply {
            text = "Swipe in from the edge, hold the arrow"
            setTextColor(sub)
            textSize = 13f
        })
        header.addView(titles)
        root.addView(header)

        // Panel status + start / stop
        val running = PanelService.running
        card("Panel") {
            addView(TextView(context).apply {
                text = if (running) "●  Running" else "●  Stopped"
                setTextColor(if (running) good else bad)
                textSize = 16f
                setPadding(0, 0, 0, dp(10))
            })
            addView(
                bigButton(if (running) "Restart panel" else "Start panel", accent) { startPanel() },
                LinearLayout.LayoutParams(MATCH_PARENT, dp(48))
            )
            if (running) {
                addView(
                    bigButton("Stop panel", 0xFF3C4043.toInt()) { stopPanel() },
                    LinearLayout.LayoutParams(MATCH_PARENT, dp(48)).apply { topMargin = dp(8) }
                )
            }
        }

        // Pro / donate
        card("Pro", highlight = true) {
            val pro = LicenseManager.isPro(context)
            val until = LicenseManager.expiry(context)
            addView(TextView(context).apply {
                text = if (pro && until != null)
                    "●  Pro active until ${until.substring(0, 4)}-${until.substring(4, 6)}-${until.substring(6)}"
                else "Free: up to ${LicenseManager.FREE_APP_LIMIT} favorite apps"
                setTextColor(if (pro) good else Color.WHITE)
                textSize = 15f
                setPadding(0, 0, 0, dp(6))
            })
            addView(TextView(context).apply {
                text = "Donate 99 pesos for the first month, then 25 pesos per month, for unlimited favorite apps."
                setTextColor(sub)
                textSize = 12f
                setPadding(0, 0, 0, dp(10))
            })
            addView(
                bigButton("Donate", accent) { showDonate() },
                LinearLayout.LayoutParams(MATCH_PARENT, dp(52))
            )
            addView(row("Enter key", "Paste the key you received after donating", null, "enterkey") { showKeyDialog() })
            addView(row("Device code", LicenseManager.deviceCode(context) + " (tap to copy)", null, "devicecode") {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Device code", LicenseManager.deviceCode(this@MainActivity)))
                toast("Device code copied")
            })
        }

        // Setup checklist
        val overlayOk = Settings.canDrawOverlays(this)
        val a11yOk = ScreenshotService.instance != null
        val batteryOk = (getSystemService(POWER_SERVICE) as PowerManager)
            .isIgnoringBatteryOptimizations(packageName)

        card("Setup") {
            addView(row(
                "Display over other apps",
                if (overlayOk) "Allowed" else "Tap to allow (required)",
                overlayOk,
                "overlay"
            ) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            })
            addView(row(
                "Screenshots and back arrow",
                if (a11yOk) "On" else "Off. Tap to turn on in Accessibility",
                a11yOk,
                "accessibility"
            ) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
            addView(row(
                "Keep running in background",
                if (batteryOk) "Unrestricted" else "Tap so Android doesn't close the panel",
                batteryOk,
                "battery"
            ) {
                runCatching {
                    startActivity(
                        Intent(
                            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:$packageName")
                        )
                    )
                }.onFailure {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            })
        }

        // Preferences (tap to change)
        val zoneText =
            if (prefs.getString(PanelService.KEY_ZONE, "full") == "middle") "Middle of the edge only"
            else "Whole edge"
        val edgeText = when (prefs.getString(PanelService.KEY_EDGE, "normal")) {
            "thin" -> "Thin"
            "wide" -> "Wide"
            else -> "Normal"
        }

        card("Preferences") {
            addView(row("Edge area", "$zoneText (tap to change)", null) {
                val next = if (prefs.getString(PanelService.KEY_ZONE, "full") == "middle") "full" else "middle"
                prefs.edit().putString(PanelService.KEY_ZONE, next).apply()
                restartIfRunning()
                render()
            })
            addView(row("Edge width", "$edgeText (tap to change)", null) {
                val next = when (prefs.getString(PanelService.KEY_EDGE, "normal")) {
                    "thin" -> "normal"
                    "normal" -> "wide"
                    else -> "thin"
                }
                prefs.edit().putString(PanelService.KEY_EDGE, next).apply()
                restartIfRunning()
                render()
            })
        }

        root.addView(
            TextView(this).apply {
                text = "If the arrow stops showing up, tap Restart panel. Some phones also have an " +
                    "\"Auto-start\" or battery page in Settings where Side Panel should be allowed."
                setTextColor(sub)
                textSize = 12f
                setPadding(dp(4), dp(16), dp(4), 0)
            }
        )
    }

    private fun showDonate() {
        val code = LicenseManager.deviceCode(this)
        android.app.AlertDialog.Builder(this)
            .setTitle("Donate")
            .setMessage(
                "99 pesos for the first month, then 25 pesos per month.\n\n" +
                    LicenseManager.DONATE_INFO + "\n\nYour device code: $code\n\n" +
                    "You will get a key back. Tap Enter key and paste it."
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showKeyDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "PANELPRO-XXXXXXXX-XXXXXXXXXXXX"
            setSingleLine()
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Enter key")
            .setView(input)
            .setPositiveButton("Activate") { _, _ ->
                when (LicenseManager.activate(this, input.text.toString())) {
                    LicenseManager.Result.OK -> toast("Pro is on. Thank you!")
                    LicenseManager.Result.EXPIRED -> toast("This key has expired")
                    LicenseManager.Result.INVALID -> toast("Key not valid for this device")
                }
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Actions ----------

    private fun startPanel() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow display over other apps first")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        prefs.edit().putBoolean(PanelService.KEY_AUTOSTART, true).apply()
        val svc = Intent(this, PanelService::class.java)
        stopService(svc)
        startForegroundService(svc)
        root.postDelayed({ render() }, 500)
    }

    private fun stopPanel() {
        prefs.edit().putBoolean(PanelService.KEY_AUTOSTART, false).apply()
        stopService(Intent(this, PanelService::class.java))
        root.postDelayed({ render() }, 300)
    }

    private fun restartIfRunning() {
        if (PanelService.running && Settings.canDrawOverlays(this)) {
            val svc = Intent(this, PanelService::class.java)
            stopService(svc)
            startForegroundService(svc)
        }
    }
}
