package com.example.sidepanel

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val bg = 0xFF0F1115.toInt()
    private val cardBg = 0xFF1B1F27.toInt()
    private val accent = 0xFF4285F4.toInt()
    private val good = 0xFF34A853.toInt()
    private val bad = 0xFFEA4335.toInt()
    private val sub = 0xFF9AA0A6.toInt()

    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences(PanelService.PREFS, MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    // ---------- Building blocks ----------

    private fun card(title: String, build: LinearLayout.() -> Unit) {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 16)
            setPadding(dp(16), dp(14), dp(16), dp(10))
        }
        c.addView(TextView(this).apply {
            text = title.uppercase()
            setTextColor(sub)
            textSize = 12f
            setPadding(0, 0, 0, dp(6))
        })
        c.build()
        root.addView(c, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(16) })
    }

    private fun row(title: String, subtitle: String, ok: Boolean?, onClick: () -> Unit): View =
        LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
            val dot = View(context).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(
                        when (ok) {
                            true -> good
                            false -> bad
                            null -> 0xFF5F6368.toInt()
                        }
                    )
                }
            }
            addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)))
            val texts = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, dp(8), 0)
            }
            texts.addView(TextView(context).apply {
                text = title
                setTextColor(Color.WHITE)
                textSize = 15f
            })
            texts.addView(TextView(context).apply {
                text = subtitle
                setTextColor(sub)
                textSize = 12f
            })
            addView(texts, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(TextView(context).apply {
                text = "›"
                setTextColor(sub)
                textSize = 22f
            })
            setOnClickListener { onClick() }
        }

    private fun bigButton(label: String, color: Int, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            background = rounded(color, 12)
            stateListAnimator = null
            setOnClickListener { onClick() }
        }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- Screen ----------

    private fun render() {
        root.removeAllViews()

        // Header
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(
            ImageView(this).apply { setImageResource(R.mipmap.ic_launcher) },
            LinearLayout.LayoutParams(dp(60), dp(60))
        )
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        titles.addView(TextView(this).apply {
            text = "Side Panel"
            setTextColor(Color.WHITE)
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
        })
        titles.addView(TextView(this).apply {
            text = "Swipe in from the edge, hold the arrow"
            setTextColor(sub)
            textSize = 13f
        })
        header.addView(titles)
        root.addView(header)

        // Panel status + start / stop
        val running = PanelService.running
        card("Panel") {
            addView(TextView(context).apply {
                text = if (running) "●  Running" else "●  Stopped"
                setTextColor(if (running) good else bad)
                textSize = 16f
                setPadding(0, 0, 0, dp(10))
            })
            addView(
                bigButton(if (running) "Restart panel" else "Start panel", accent) { startPanel() },
                LinearLayout.LayoutParams(MATCH_PARENT, dp(48))
            )
            if (running) {
                addView(
                    bigButton("Stop panel", 0xFF3C4043.toInt()) { stopPanel() },
                    LinearLayout.LayoutParams(MATCH_PARENT, dp(48)).apply { topMargin = dp(8) }
                )
            }
        }

        // Setup checklist
        val overlayOk = Settings.canDrawOverlays(this)
        val a11yOk = ScreenshotService.instance != null
        val batteryOk = (getSystemService(POWER_SERVICE) as PowerManager)
            .isIgnoringBatteryOptimizations(packageName)
        val freeformOk = PanelService.freeformOn(this)

        card("Setup") {
            addView(row(
                "Display over other apps",
                if (overlayOk) "Allowed" else "Tap to allow (required)",
                overlayOk
            ) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            })
            addView(row(
                "Screenshots, split screen, back arrow",
                if (a11yOk) "On" else "Off. Tap to turn on in Accessibility",
                a11yOk
            ) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
            addView(row(
                "Keep running in background",
                if (batteryOk) "Unrestricted" else "Tap so Android doesn't close the panel",
                batteryOk
            ) {
                runCatching {
                    startActivity(
                        Intent(
                            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:$packageName")
                        )
                    )
                }.onFailure {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            })
            addView(row(
                "Small windows (freeform)",
                when {
                    !freeformOk -> "Off. Needs Developer options"
                    !PanelService.forceResizableOn(context) ->
                        "On. Also turn on \"Force activities to be resizable\""
                    else -> "On"
                },
                freeformOk
            ) {
                runCatching { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
                    .onFailure { startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)) }
            })
        }

        // Preferences (tap to change)
        val modeText = when (PanelService.mode(this)) {
            "small" -> "Small window"
            "split" -> "Split screen"
            else -> "Full screen"
        }
        val zoneText =
            if (prefs.getString(PanelService.KEY_ZONE, "full") == "middle") "Middle of the edge only"
            else "Whole edge"
        val edgeText = when (prefs.getString(PanelService.KEY_EDGE, "normal")) {
            "thin" -> "Thin"
            "wide" -> "Wide"
            else -> "Normal"
        }

        card("Preferences") {
            addView(row("Open apps as", "$modeText (tap to change)", null) {
                val next = when (PanelService.mode(this@MainActivity)) {
                    "small" -> "split"
                    "split" -> "full"
                    else -> "small"
                }
                prefs.edit().putString(PanelService.KEY_MODE, next).apply()
                render()
            })
            addView(row("Edge area", "$zoneText (tap to change)", null) {
                val next = if (prefs.getString(PanelService.KEY_ZONE, "full") == "middle") "full" else "middle"
                prefs.edit().putString(PanelService.KEY_ZONE, next).apply()
                restartIfRunning()
                render()
            })
            addView(row("Edge width", "$edgeText (tap to change)", null) {
                val next = when (prefs.getString(PanelService.KEY_EDGE, "normal")) {
                    "thin" -> "normal"
                    "normal" -> "wide"
                    else -> "thin"
                }
                prefs.edit().putString(PanelService.KEY_EDGE, next).apply()
                restartIfRunning()
                render()
            })
        }

        root.addView(
            TextView(this).apply {
                text = "If the arrow stops showing up, tap Restart panel. Some phones also have an " +
                    "\"Auto-start\" or battery page in Settings where Side Panel should be allowed."
                setTextColor(sub)
                textSize = 12f
                setPadding(dp(4), dp(16), dp(4), 0)
            }
        )
    }

    // ---------- Actions ----------

    private fun startPanel() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow display over other apps first")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        prefs.edit().putBoolean(PanelService.KEY_AUTOSTART, true).apply()
        val svc = Intent(this, PanelService::class.java)
        stopService(svc)
        startForegroundService(svc)
        root.postDelayed({ render() }, 500)
    }

    private fun stopPanel() {
        prefs.edit().putBoolean(PanelService.KEY_AUTOSTART, false).apply()
        stopService(Intent(this, PanelService::class.java))
        root.postDelayed({ render() }, 300)
    }

    private fun restartIfRunning() {
        if (PanelService.running && Settings.canDrawOverlays(this)) {
            val svc = Intent(this, PanelService::class.java)
            stopService(svc)
            startForegroundService(svc)
        }
    }
}
