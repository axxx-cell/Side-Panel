package com.example.sidepanel

import android.content.Context
import android.provider.Settings
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Offline Pro licence. A key looks like PANELPRO-20261130-A1B2C3D4E5F6 and only works on one device. */
object LicenseManager {
    const val FREE_APP_LIMIT = 5

    // EDIT THIS: how people donate and where they send the receipt + device code.
    const val DONATE_INFO = "GCash / Maya: add your number here\nThen send your receipt and device code to: add your contact here"

    // Must match SECRET in keygen.html. Keep both private.
    private const val SECRET = "87c8761c355d42a0fc814da90260758d"
    private const val PREFS = "license"
    private const val PREF_KEY = "key"

    enum class Result { OK, INVALID, EXPIRED }

    /** Short code shown in the app; the buyer sends it to you with the payment. */
    fun deviceCode(context: Context): String {
        val id = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val h = hex(MessageDigest.getInstance("SHA-256").digest((id + context.packageName).toByteArray()))
        val c = h.substring(0, 8).uppercase()
        return c.substring(0, 4) + "-" + c.substring(4)
    }

    fun activate(context: Context, rawKey: String): Result {
        val r = check(context, rawKey)
        if (r == Result.OK) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(PREF_KEY, rawKey.trim().uppercase()).apply()
        }
        return r
    }

    fun isPro(context: Context): Boolean {
        val k = stored(context) ?: return false
        return check(context, k) == Result.OK
    }

    /** "20261130" while Pro is active, otherwise null. */
    fun expiry(context: Context): String? {
        val k = stored(context) ?: return null
        return if (check(context, k) == Result.OK) k.split("-")[1] else null
    }

    private fun stored(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PREF_KEY, null)

    private fun check(context: Context, rawKey: String): Result {
        val parts = rawKey.trim().uppercase().split("-")
        if (parts.size != 3 || parts[0] != "PANELPRO") return Result.INVALID
        val expiry = parts[1]
        if (expiry.length != 8 || !expiry.all { it.isDigit() }) return Result.INVALID
        val device = deviceCode(context).replace("-", "")
        if (sign(expiry, device) != parts[2]) return Result.INVALID
        return if (expiry >= today()) Result.OK else Result.EXPIRED
    }

    private fun sign(expiry: String, device: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(SECRET.toByteArray(), "HmacSHA256"))
        return hex(mac.doFinal("$expiry|$device".toByteArray())).substring(0, 12).uppercase()
    }

    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
}
