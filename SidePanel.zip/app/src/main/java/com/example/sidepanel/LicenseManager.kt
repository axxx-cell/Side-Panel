package com.example.sidepanel

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Offline Pro licence. A key looks like PANELPRO-20261130-A1B2C3D4E5F6 and only works on one device. */
object LicenseManager {
    const val FREE_APP_LIMIT = 5

    // EDIT THIS: how people donate and where they send the receipt + device code.
    const val DONATE_INFO = "GCash / Maya: add your number here\nThen send your receipt and device code to: add your contact here"

    // Shown in the Donate window and used by the Send receipt / mailbox buttons.
    const val GCASH_NUMBER = "09097574108"
    const val CONTACT_EMAIL = "ax020318@gmail.com"

    // Pro list: one line per buyer, "DEVICE-CODE YYYY-MM-DD" (example: D93C-39B5 2026-12-01).
    // The repo must be public for the app to read it.
    const val PRO_LIST_URL = "https://raw.githubusercontent.com/axxx-cell/Side-Panel/main/pro.txt"
    private const val PREF_REMOTE = "remote_expiry"
    private const val PREF_CHECKED = "remote_checked"

    // Must match SECRET in keygen.html. Keep both private.
    private const val SECRET = "87c8761c355d42a0fc814da90260758d"
    private const val PREFS = "license"
    private const val PREF_KEY = "key"

    enum class Result { OK, INVALID, EXPIRED }

    /** Short code shown in the app; the buyer sends it to you with the payment. */
    fun deviceCode(context: Context): String {
        val id = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val h = hex(MessageDigest.getInstance("SHA-256").digest((id + context.packageName).toByteArray()))
        val c = h.substring(0, 8).uppercase()
        return c.substring(0, 4) + "-" + c.substring(4)
    }

    fun activate(context: Context, rawKey: String): Result {
        val r = check(context, rawKey)
        if (r == Result.OK) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(PREF_KEY, rawKey.trim().uppercase()).apply()
        }
        return r
    }

    fun isPro(context: Context): Boolean = expiry(context) != null

    /** "20261130" while Pro is active (key or Pro list), otherwise null. */
    fun expiry(context: Context): String? {
        val k = stored(context)
        val keyExp = if (k != null && check(context, k) == Result.OK) k.split("-")[1] else null
        val listExp = remoteExpiry(context)
        return listOfNotNull(keyExp, listExp).maxOrNull()
    }

    private fun remoteExpiry(context: Context): String? {
        val e = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PREF_REMOTE, null)
        return if (e != null && e.length == 8 && e >= today()) e else null
    }

    /**
     * Looks for this phone's device code on the Pro list. Runs in the background.
     * onDone(found, becamePro): found is true/false, or null if the phone could not reach the list.
     */
    fun refresh(context: Context, force: Boolean = false, onDone: ((Boolean?, Boolean) -> Unit)? = null) {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (!force && now - prefs.getLong(PREF_CHECKED, 0L) < 10 * 60 * 1000L) return
        val before = isPro(app)
        Thread {
            var found: Boolean? = null
            try {
                val con = URL("$PRO_LIST_URL?t=$now").openConnection() as HttpURLConnection
                con.connectTimeout = 8000
                con.readTimeout = 8000
                if (con.responseCode == 200) {
                    val me = deviceCode(app).uppercase()
                    var exp: String? = null
                    con.inputStream.bufferedReader().useLines { lines ->
                        lines.forEach { line ->
                            val t = line.trim()
                            if (t.isEmpty() || t.startsWith("#")) return@forEach
                            val parts = t.split(Regex("\\s+"))
                            if (parts.size >= 2 && parts[0].uppercase() == me) {
                                val d = parts[1].replace("-", "")
                                if (d.length == 8 && d.all { it.isDigit() } && (exp == null || d > exp!!)) exp = d
                            }
                        }
                    }
                    val ed = prefs.edit().putLong(PREF_CHECKED, now)
                    if (exp != null) ed.putString(PREF_REMOTE, exp) else ed.remove(PREF_REMOTE)
                    ed.apply()
                    found = exp != null
                }
                con.disconnect()
            } catch (e: Exception) {
                found = null
            }
            val result = found
            Handler(Looper.getMainLooper()).post {
                onDone?.invoke(result, !before && isPro(app))
            }
        }.start()
    }

    private fun stored(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PREF_KEY, null)

    private fun check(context: Context, rawKey: String): Result {
        val parts = rawKey.trim().uppercase().split("-")
        if (parts.size != 3 || parts[0] != "PANELPRO") return Result.INVALID
        val expiry = parts[1]
        if (expiry.length != 8 || !expiry.all { it.isDigit() }) return Result.INVALID
        val device = deviceCode(context).replace("-", "")
        if (sign(expiry, device) != parts[2]) return Result.INVALID
        return if (expiry >= today()) Result.OK else Result.EXPIRED
    }

    private fun sign(expiry: String, device: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(SECRET.toByteArray(), "HmacSHA256"))
        return hex(mac.doFinal("$expiry|$device".toByteArray())).substring(0, 12).uppercase()
    }

    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
}
