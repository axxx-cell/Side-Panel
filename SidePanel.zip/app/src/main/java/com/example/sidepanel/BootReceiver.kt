package com.example.sidepanel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Brings the panel back after the phone restarts (if it was running before). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences(PanelService.PREFS, Context.MODE_PRIVATE)
        if (Settings.canDrawOverlays(context) && prefs.getBoolean(PanelService.KEY_AUTOSTART, false)) {
            runCatching {
                context.startForegroundService(Intent(context, PanelService::class.java))
            }
        }
    }
}
