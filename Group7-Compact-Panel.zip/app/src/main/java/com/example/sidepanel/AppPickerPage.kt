package com.example.sidepanel

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.text.TextUtils
import android.util.LruCache
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** "Edit apps": tap an app to add or remove it from the favorites column. */
class AppPickerPage(private val ctx: Context, private val host: PanelHost) : LinearLayout(ctx) {

    private val all = ArrayList<AppItem>()
    private val icons = LruCache<String, Drawable>(60)
    private val title = ctx.label("", 13f, C.TEXT2)
    private val rows = Rows()

    private fun limit() = if (host.pro().isPro) 24 else ProLogic.FREE_APPS

    init {
        orientation = VERTICAL
        addView(title, LayoutParams(MATCH, WRAP))
        val rv = RecyclerView(ctx).apply {
            layoutManager = LinearLayoutManager(ctx)
            adapter = rows
            overScrollMode = OVER_SCROLL_NEVER
        }
        addView(rv, LayoutParams(MATCH, 0, 1f).apply { topMargin = ctx.dp(8) })
        refresh()
        host.scope.launch {
            val items = withContext(Dispatchers.IO) {
                val pm = ctx.packageManager
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                pm.queryIntentActivities(intent, 0)
                    .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
                    .filter { it.pkg != ctx.packageName }
                    .distinctBy { it.pkg }
                    .sortedBy { it.label.lowercase() }
            }
            all.clear(); all.addAll(items)
            refresh()
        }
    }

    fun refresh() {
        title.text = "Choose favorites  ${host.favorites().size}/${limit()}"
        rows.notifyDataSetChanged()
    }

    private fun toggle(pkg: String) {
        val cur = host.favorites().toMutableList()
        if (pkg in cur) {
            cur.remove(pkg)
        } else {
            if (cur.size >= limit()) {
                ctx.toast(if (host.pro().isPro) "Maximum ${limit()} favorites" else "Free plan: ${limit()} favorites. Pro unlocks more.")
                return
            }
            cur.add(pkg)
        }
        host.setFavorites(cur)
        refresh()
    }

    private inner class VH(val row: LinearLayout, val icon: ImageView, val name: TextView, val check: TextView) :
        RecyclerView.ViewHolder(row)

    private inner class Rows : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val row = LinearLayout(parent.context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(ctx.dp(8), 0, ctx.dp(8), 0)
                layoutParams = RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, ctx.dp(48))
            }
            val icon = ImageView(parent.context)
            row.addView(icon, LayoutParams(ctx.dp(32), ctx.dp(32)))
            val name = ctx.label("", 13f, Color.WHITE).apply {
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(ctx.dp(10), 0, ctx.dp(6), 0)
            }
            row.addView(name, LayoutParams(0, WRAP, 1f))
            val check = ctx.label("", 16f, C.GREEN, true)
            row.addView(check, LayoutParams(WRAP, WRAP))
            return VH(row, icon, name, check)
        }

        override fun getItemCount() = all.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val app = all[position]
            h.name.text = app.label
            h.check.text = if (app.pkg in host.favorites()) "\u2713" else ""
            h.row.tag = app.pkg
            h.row.setOnClickListener { toggle(app.pkg) }
            val cached = icons.get(app.pkg)
            if (cached != null) {
                h.icon.setImageDrawable(cached)
            } else {
                h.icon.setImageDrawable(null)
                host.scope.launch {
                    val dr = withContext(Dispatchers.IO) {
                        runCatching { ctx.packageManager.getApplicationIcon(app.pkg) }.getOrNull()
                    }
                    if (dr != null) {
                        icons.put(app.pkg, dr)
                        if (h.row.tag == app.pkg) h.icon.setImageDrawable(dr)
                    }
                }
            }
        }
    }
}
