package com.example.sidepanel

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import androidx.activity.ComponentActivity
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Futuristic home screen: setup guide, trial status, themes and settings. */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch { applicationContext.ensureTrialStart() }
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch { show(dataStore.data.first()) }   // re-check the steps when you come back
    }

    private fun themeFor(p: Preferences): Int =
        if (ProLogic.state(p).isPro) (p[Keys.THEME] ?: 0) else 0

    private fun show(p: Preferences) {
        C.applyTheme(themeFor(p))
        render(p)
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        return s?.contains("$packageName/") == true
    }

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    private fun neonButton(text: String, onClick: () -> Unit) =
        label(text, 13f, 0xFF05101F.toInt(), true).apply {
            letterSpacing = 0.04f
            background = glass(22, C.CYAN)
            setPadding(dp(20), dp(10), dp(20), dp(10))
            setOnClickListener { onClick() }
        }

    private fun section(root: LinearLayout, title: String) {
        root.addView(label(title.uppercase(), 12f, C.CYAN, true).apply {
            letterSpacing = 0.2f
            setPadding(0, dp(28), 0, dp(12))
        })
    }

    private fun radio(text: String, rid: Int) = RadioButton(this).apply {
        id = rid
        this.text = text
        setTextColor(Color.WHITE)
        buttonTintList = ColorStateList.valueOf(C.CYAN)
    }

    private fun addStep(
        root: LinearLayout, n: Int, title: String, body: String, done: Boolean,
        extra: View? = null, actions: List<Pair<String, () -> Unit>> = emptyList()
    ) {
        val accent = if (done) C.GREEN else C.CYAN
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(20, withAlpha(C.GLASS, 0xB0)).apply { setStroke(dp(1), withAlpha(accent, 0x55)) }
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val badge = label(if (done) "\u2713" else "$n", 13f, if (done) Color.BLACK else accent, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                if (done) setColor(accent) else { setColor(0x00000000); setStroke(dp(2), accent) }
            }
        }
        head.addView(badge, lp(dp(28), dp(28)))
        head.addView(label(title, 15f, Color.WHITE, true).apply { setPadding(dp(12), 0, 0, 0) })
        card.addView(head)
        card.addView(label(body, 13f, C.LABEL).apply {
            setPadding(0, dp(10), 0, dp(4))
            setLineSpacing(0f, 1.15f)
        })
        if (extra != null) card.addView(extra, lp(MATCH, WRAP).apply { topMargin = dp(8) })
        actions.forEach { (t, f) -> card.addView(neonButton(t, f), lp(WRAP, WRAP).apply { topMargin = dp(10) }) }
        root.addView(card, lp(MATCH, WRAP).apply { bottomMargin = dp(14) })
    }

    private fun render(p: Preferences) {
        val state = ProLogic.state(p)
        val hasKey = !p[Keys.API_KEY].isNullOrBlank()
        val on = serviceOn()
        val done = listOf(on, on, hasKey, hasKey).count { it }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(56), dp(20), dp(40))
        }

        // ---- hero ----
        root.addView(label("SIDE PANEL", 30f, Color.WHITE, true).apply { letterSpacing = 0.18f })
        root.addView(label("Your edge command center", 13f, C.TEXT2).apply {
            letterSpacing = 0.08f; setPadding(0, dp(4), 0, 0)
        })
        root.addView(
            label(state.label().uppercase(), 11f, C.CYAN, true).apply {
                letterSpacing = 0.12f
                background = glass(14, withAlpha(C.CYAN, 0x22)).apply { setStroke(dp(1), withAlpha(C.CYAN, 0x88)) }
                setPadding(dp(12), dp(5), dp(12), dp(5))
            },
            lp(WRAP, WRAP).apply { topMargin = dp(14) }
        )
        val statusText = when (state.plan) {
            Plan.TRIAL -> "Your free Pro trial has ${state.daysLeft} day(s) left. Every feature and theme is unlocked."
            Plan.PRO -> "Pro is active. Thank you for supporting the app!"
            Plan.FREE -> "Your trial has ended. Free plan: 5 apps, no File Dock, Neon theme only. Payment options are coming in a future update."
        }
        root.addView(label(statusText, 13f, C.LABEL).apply { setPadding(0, dp(12), 0, dp(16)) })

        root.addView(label("$done of 4 checks ready", 11f, C.TEXT2).apply { setPadding(0, 0, 0, dp(6)) })
        val bar = LinearLayout(this).apply { background = glass(3, withAlpha(C.DOT_OFF, 0x99)) }
        bar.addView(View(this).apply { background = glass(3, C.CYAN) }, LinearLayout.LayoutParams(0, MATCH, done.toFloat()))
        bar.addView(View(this), LinearLayout.LayoutParams(0, MATCH, (4 - done).toFloat()))
        root.addView(bar, lp(MATCH, dp(6)))

        // ---- setup guide ----
        section(root, "Setup guide")

        addStep(
            root, 1, "Allow restricted settings",
            "If you installed this app from outside the Play Store, Android 13+ may grey out the Accessibility switch.\n" +
                "1. Tap \"Open App info\".\n2. Tap the \u22ee menu at the top-right.\n" +
                "3. Tap \"Allow restricted settings\" and confirm.\n(No \u22ee menu? Skip this step.)",
            on,
            actions = listOf("Open App info" to {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            })
        )

        addStep(
            root, 2, "Turn on the panel",
            "1. Tap \"Open Accessibility\".\n2. Find Side Panel (under Installed apps or Downloaded apps).\n" +
                "3. Switch it ON and tap Allow.\nThis step shows a green check when it is on.",
            on,
            actions = listOf("Open Accessibility" to { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        )

        addStep(
            root, 3, "Open the panel",
            "Swipe left from the small glowing handle on the right edge of the screen. It works in portrait and in landscape games.\n" +
                "Left side: your favorite apps (tap Edit apps to choose them). Right side: tools like Calculator, Notes and Last app. Tap Ask AI at the bottom to chat.\n" +
                "Panel won't open? Set the trigger width to 24dp below.",
            false
        )

        addStep(
            root, 4, "Get your free AI key",
            "An API key is a free password that lets this app talk to Google's AI. You make it once and it takes about 2 minutes.\n" +
                "1. Tap \"Open Google AI Studio\" and sign in with a Google account.\n" +
                "2. Tap \"Create API key\".\n3. Copy the key (a long text starting with AIza).\n4. Come back here and paste it in step 5.",
            hasKey,
            actions = listOf("Open Google AI Studio" to {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey")))
            })
        )

        val keyField = EditText(this).apply {
            hint = "Paste your key here"
            setHintTextColor(C.TEXT2)
            setTextColor(Color.WHITE)
            textSize = 13f
            setSingleLine(true)
            background = glass(14, 0x55000000)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        addStep(
            root, 5, "Paste your key",
            if (hasKey) "A key is saved. Paste a new one to replace it." else "Paste the key and tap Save. It is stored only on this phone.",
            hasKey,
            extra = keyField,
            actions = listOf("Save key" to {
                val k = keyField.text.toString().trim()
                if (k.length < 20) toast("That does not look like a key")
                else lifecycleScope.launch {
                    dataStore.edit { it[Keys.API_KEY] = k }
                    toast("Key saved")
                    show(dataStore.data.first())
                }
            })
        )

        // ---- customize ----
        section(root, "Customize")
        val customize = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(20, withAlpha(C.GLASS, 0xB0)).apply { setStroke(dp(1), withAlpha(C.CYAN, 0x33)) }
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        customize.addView(label(if (state.isPro) "Theme" else "Theme  \uD83D\uDD12 Pro", 14f, Color.WHITE, true))
        val themeRow = LinearLayout(this)
        val cur = themeFor(p)
        C.THEMES.forEachIndexed { i, name ->
            val pal = C.PALETTES[i]
            val swatch = View(this).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(pal.accent, pal.accent2)).apply {
                    shape = GradientDrawable.OVAL
                    if (i == cur) setStroke(dp(3), Color.WHITE) else setStroke(dp(1), 0x44FFFFFF)
                }
            }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dp(12), 0, 0)
                setOnClickListener {
                    if (!state.isPro && i != 0) toast("Themes are a Pro feature")
                    else lifecycleScope.launch {
                        dataStore.edit { it[Keys.THEME] = i }
                        show(dataStore.data.first())
                    }
                }
            }
            col.addView(swatch, lp(dp(44), dp(44)))
            col.addView(label(name, 11f, C.LABEL).apply { setPadding(0, dp(6), 0, 0) })
            themeRow.addView(col, lp(0, WRAP).apply { weight = 1f })
        }
        customize.addView(themeRow)

        val nav = runCatching { Settings.Secure.getInt(contentResolver, "navigation_mode", 0) }.getOrDefault(0)
        val defaultDp = if (nav == 2) 12 else 18

        customize.addView(label("Panel size", 14f, Color.WHITE, true).apply { setPadding(0, dp(20), 0, 0) })
        val sizeGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("Small", "Medium", "Large").forEachIndexed { i, name -> sizeGroup.addView(radio(name, 100 + i)) }
        sizeGroup.check(100 + (p[Keys.PANEL_SIZE] ?: 0))
        sizeGroup.setOnCheckedChangeListener { _, id ->
            lifecycleScope.launch { dataStore.edit { it[Keys.PANEL_SIZE] = id - 100 } }
        }
        customize.addView(sizeGroup)

        customize.addView(label("Edge trigger width", 14f, Color.WHITE, true).apply { setPadding(0, dp(16), 0, 0) })
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf(12, 18, 24).forEach { v -> group.addView(radio("${v}dp", v)) }
        group.check(p[Keys.TRIGGER_DP] ?: defaultDp)
        group.setOnCheckedChangeListener { _, id ->
            lifecycleScope.launch { dataStore.edit { it[Keys.TRIGGER_DP] = id } }
        }
        customize.addView(group)

        val landscape = Switch(this).apply {
            text = "Enable in landscape games"
            setTextColor(Color.WHITE)
            setPadding(0, dp(16), 0, 0)
            isChecked = p[Keys.LANDSCAPE] ?: true
            setOnCheckedChangeListener { _, checked ->
                lifecycleScope.launch { dataStore.edit { it[Keys.LANDSCAPE] = checked } }
            }
        }
        customize.addView(landscape)
        root.addView(customize, lp(MATCH, WRAP))

        setContentView(ScrollView(this).apply {
            background = aurora()
            isVerticalScrollBarEnabled = false
            addView(root)
        })
    }
}
