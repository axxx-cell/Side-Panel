package com.example.sidepanel

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "panel_settings")

object Keys {
    val TRIGGER_DP = intPreferencesKey("trigger_dp")        // 12 / 18 / 24
    val LANDSCAPE = booleanPreferencesKey("landscape_enabled") // default ON
}
