package com.example.sidepanel

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        fun label(t: String, size: Float) = TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.WHITE); setPadding(0, dp(16), 0, dp(8))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(20))
            setBackgroundColor(0xFF181E3A.toInt())
        }
        root.addView(label("Side Panel", 26f))
        root.addView(Button(this).apply {
            text = "Turn on in Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(label("Edge trigger width", 16f))
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf(12, 18, 24).forEach { v ->
            group.addView(RadioButton(this).apply { id = v; text = "${v}dp"; setTextColor(Color.WHITE) })
        }
        root.addView(group)
        val landscape = Switch(this).apply {
            text = "Enable in landscape games"; setTextColor(Color.WHITE)
            setPadding(0, dp(16), 0, 0)
        }
        root.addView(landscape)
        setContentView(root)

        lifecycleScope.launch {
            val p = dataStore.data.first()
            group.check(p[Keys.TRIGGER_DP] ?: 18)
            landscape.isChecked = p[Keys.LANDSCAPE] ?: true
            group.setOnCheckedChangeListener { _, id ->
                lifecycleScope.launch { dataStore.edit { it[Keys.TRIGGER_DP] = id } }
            }
            landscape.setOnCheckedChangeListener { _, on ->
                lifecycleScope.launch { dataStore.edit { it[Keys.LANDSCAPE] = on } }
            }
        }
    }
}
