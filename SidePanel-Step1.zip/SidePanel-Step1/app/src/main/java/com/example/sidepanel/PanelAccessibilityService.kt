package com.example.sidepanel

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as WLP
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class PanelAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var wm: WindowManager
    private lateinit var displayManager: DisplayManager

    private var trigger: EdgeTrigger? = null
    private var panel: PanelView? = null
    private var panelShown = false
    private var panelWidthPx = 0

    private var lastPackage: String? = null
    private var ignored: Set<String> = emptySet()

    private var triggerDp = 18
    private var landscapeEnabled = true
    private var lastKey = ""

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) = relayout()
    }

    // ---------- lifecycle ----------

    override fun onServiceConnected() {
        super.onServiceConnected()
        removeViews()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        displayManager = getSystemService(DISPLAY_SERVICE) as DisplayManager

        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        ignored = imm.enabledInputMethodList.map { it.packageName }.toSet() +
            setOf("com.android.systemui", packageName)

        triggerDp = defaultTriggerDp()

        val p = PanelView(this, scope, onBack = { goBack() }, onLaunch = { launchPackage(it) })
        p.onOutside = { hidePanel() }
        p.visibility = View.INVISIBLE
        panel = p

        val t = EdgeTrigger(this) { showPanel() }
        trigger = t

        wm.addView(p, panelParams(false))   // pre-inflated and dormant
        wm.addView(t, triggerParams())

        displayManager.registerDisplayListener(displayListener, Handler(Looper.getMainLooper()))

        scope.launch {
            applicationContext.dataStore.data.collect { prefs ->
                triggerDp = prefs[Keys.TRIGGER_DP] ?: defaultTriggerDp()
                landscapeEnabled = prefs[Keys.LANDSCAPE] ?: true
                relayout()
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg !in ignored) lastPackage = pkg   // remembered BEFORE the panel opens
    }

    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        relayout()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        removeViews()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        removeViews()
        scope.cancel()
        super.onDestroy()
    }

    private fun removeViews() {
        if (::displayManager.isInitialized) {
            runCatching { displayManager.unregisterDisplayListener(displayListener) }
        }
        if (::wm.isInitialized) {
            trigger?.let { v -> runCatching { wm.removeView(v) } }
            panel?.let { v -> runCatching { wm.removeView(v) } }
        }
        trigger = null; panel = null; panelShown = false; lastKey = ""
    }

    // ---------- open / close ----------

    private fun showPanel() {
        val p = panel ?: return
        if (panelShown) return
        panelShown = true
        @Suppress("DEPRECATION")
        trigger?.performHapticFeedback(
            HapticFeedbackConstants.VIRTUAL_KEY,
            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
        )
        applyPanelWindow(true)
        p.animateIn(panelWidthPx)
    }

    private fun hidePanel() {
        val p = panel ?: return
        if (!panelShown) return
        panelShown = false
        p.animateOut { applyPanelWindow(false) }
    }

    private fun launchPackage(pkg: String) {
        hidePanel()
        packageManager.getLaunchIntentForPackage(pkg)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            runCatching { startActivity(it) }
        }
    }

    /** Back arrow: return to the app that was in front before the panel opened. */
    private fun goBack() {
        val pkg = lastPackage
        if (pkg != null) launchPackage(pkg) else hidePanel()
    }

    // ---------- layout (portrait + landscape, all rotations) ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun screenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    private fun defaultTriggerDp(): Int {
        val mode = runCatching { Settings.Secure.getInt(contentResolver, "navigation_mode", 0) }.getOrDefault(0)
        return if (mode == 2) 12 else 18   // 2 = gesture navigation
    }

    private fun triggerParams(): WLP {
        val (w, h) = screenSize()
        val margin = if (w > h) dp(40) else dp(120)   // shorter dead zone in landscape
        return WLP(
            dp(triggerDp),
            (h - 2 * margin).coerceAtLeast(dp(200)),
            WLP.TYPE_ACCESSIBILITY_OVERLAY,
            WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCH_MODAL or
                WLP.FLAG_LAYOUT_IN_SCREEN or WLP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.TOP
            y = margin
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode =
                WLP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun panelParams(active: Boolean): WLP {
        val (w, h) = screenSize()
        panelWidthPx = if (w > h) minOf(dp(380), (w * 0.6f).toInt())
        else minOf(dp(320), (w * 0.85f).toInt())
        // Not focusable on purpose: the game keeps focus and does not pause.
        // Step 2 (Notes / AI pages) will clear FLAG_NOT_FOCUSABLE only while typing.
        var flags = WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCH_MODAL or
            WLP.FLAG_WATCH_OUTSIDE_TOUCH or WLP.FLAG_LAYOUT_IN_SCREEN or WLP.FLAG_LAYOUT_NO_LIMITS
        if (!active) flags = flags or WLP.FLAG_NOT_TOUCHABLE   // dormant = invisible + untouchable
        return WLP(
            panelWidthPx, WLP.MATCH_PARENT,
            WLP.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.TOP
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode =
                WLP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun applyPanelWindow(active: Boolean) {
        val p = panel ?: return
        runCatching { wm.updateViewLayout(p, panelParams(active)) }
    }

    private fun relayout() {
        val t = trigger ?: return
        val p = panel ?: return
        val (w, h) = screenSize()
        val key = "$w,$h,$triggerDp,$landscapeEnabled"
        if (key == lastKey) return
        lastKey = key
        t.visibility = if (w > h && !landscapeEnabled) View.GONE else View.VISIBLE
        runCatching { wm.updateViewLayout(t, triggerParams()) }
        runCatching { wm.updateViewLayout(p, panelParams(panelShown)) }
    }
}
