package com.example.sidepanel

import android.content.Context
import android.view.Gravity
import android.widget.LinearLayout

/** Placeholder so the project compiles. The real AI Search page comes in the next group. */
class SearchPage(ctx: Context, @Suppress("UNUSED_PARAMETER") host: PanelHost) : LinearLayout(ctx) {
    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        addView(ctx.label("AI Search \u2013 coming in the next group", 14f, C.TEXT2))
    }
    fun refreshState() {}
    fun setActive(on: Boolean) {}
}
