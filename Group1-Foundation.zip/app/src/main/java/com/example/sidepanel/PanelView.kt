package com.example.sidepanel

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlinx.coroutines.CoroutineScope

/** What the panel needs from the service. */
interface PanelHost {
    val scope: CoroutineScope
    fun pro(): ProState
    fun apiKey(): String
    suspend fun loadNote(): String
    fun saveNote(text: String)
    fun goBack()
    fun launchPackage(pkg: String)
    fun openApp()                    // opens the setup guide / settings screen
    fun setTyping(on: Boolean)       // makes the window focusable only while typing
    fun startActivity(i: Intent)
}

/** Invisible strip on the right edge + a small visible handle. Swipe left 30dp to open. */
class EdgeTrigger(context: Context, private val onOpen: () -> Unit) : FrameLayout(context) {
    private val d = resources.displayMetrics.density
    private val threshold = 30 * d
    private var downX = 0f
    private var opened = false

    init {
        val handle = View(context).apply {
            background = GradientDrawable().apply {
                cornerRadius = 4 * d
                setColor(0x9900F5FF.toInt())
            }
        }
        addView(handle, LayoutParams((4 * d).toInt(), (56 * d).toInt(), Gravity.END or Gravity.CENTER_VERTICAL))
        addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            if (Build.VERSION.SDK_INT >= 29) {
                val h = b - t
                val w = r - l
                val ex = (200 * d).toInt().coerceAtMost(h)
                val top = (h - ex) / 2
                systemGestureExclusionRects = listOf(Rect(0, top, w, top + ex))
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.rawX; opened = false }
            MotionEvent.ACTION_MOVE ->
                if (!opened && downX - e.rawX >= threshold) { opened = true; onOpen() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> opened = false
        }
        return true
    }
}

/** The panel: header, 5 vertical pages, 5 dots. Built once and kept dormant so opening is instant. */
class PanelView(context: Context, private val host: PanelHost) : LinearLayout(context) {

    var onOutside: (() -> Unit)? = null

    private val appsPage = AppsPage(context, host)
    private val calcPage = CalcPage(context)
    private val notesPage = NotesPage(context, host)
    private val chatPage = ChatPage(context, host)
    private val searchPage = SearchPage(context, host)
    private val badge: TextView
    private val dots = LinearLayout(context)

    init {
        orientation = VERTICAL
        background = panelBackground()
        val base = context.dp(12)
        setPadding(base, base, base, base)
        ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(base, i.top + base, i.right + base, i.bottom + base)
            insets
        }

        val header = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(context.label("\u2190", 22f).apply {
            gravity = Gravity.CENTER; setOnClickListener { host.goBack() }
        }, LayoutParams(context.dp(40), context.dp(40)))
        header.addView(context.label("Side Panel", 16f, Color.WHITE, true), LayoutParams(0, WRAP, 1f))
        badge = context.label("", 10f, C.CYAN).apply {
            background = context.glass(10, 0x332A2F5A)
            setPadding(context.dp(8), context.dp(3), context.dp(8), context.dp(3))
        }
        header.addView(badge)
        header.addView(context.label("?", 18f, C.CYAN, true).apply {
            gravity = Gravity.CENTER; setOnClickListener { host.openApp() }
        }, LayoutParams(context.dp(40), context.dp(40)))
        addView(header, LayoutParams(MATCH, WRAP))

        val pager = ViewPager2(context).apply {
            orientation = ViewPager2.ORIENTATION_VERTICAL
            offscreenPageLimit = 4
            adapter = PagesAdapter(listOf<View>(appsPage, calcPage, notesPage, chatPage, searchPage))
            registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    updateDots(position)
                    host.setTyping(false)
                }
            })
        }
        addView(pager, LayoutParams(MATCH, 0, 1f))

        dots.gravity = Gravity.CENTER
        repeat(5) {
            val dot = View(context).apply {
                background = GradientDrawable().apply { cornerRadius = context.dp(3).toFloat(); setColor(C.DOT_OFF) }
            }
            dots.addView(dot, LayoutParams(context.dp(6), context.dp(6)).apply {
                setMargins(context.dp(3), 0, context.dp(3), 0)
            })
        }
        addView(dots, LayoutParams(MATCH, context.dp(18)))
        updateDots(0)
        refresh()
    }

    private fun panelBackground(): LayerDrawable {
        val r = context.dp(24).toFloat()
        val radii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
        val base = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xE0181E3A.toInt(), 0xE0211E4A.toInt())
        ).apply { cornerRadii = radii }
        fun blob(color: Int, cx: Float, cy: Float) = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = context.dp(240).toFloat()
            setGradientCenter(cx, cy)
            colors = intArrayOf(color, 0x00000000)
            cornerRadii = radii
        }
        // aurora glows at about 8% opacity
        return LayerDrawable(arrayOf(base, blob(0x1400F5FF, 0.9f, 0.1f), blob(0x146366F1, 0.1f, 0.9f)))
    }

    private fun updateDots(active: Int) {
        for (i in 0 until dots.childCount) {
            val v = dots.getChildAt(i)
            val lp = v.layoutParams as LayoutParams
            lp.width = context.dp(if (i == active) 24 else 6)
            v.layoutParams = lp
            (v.background as GradientDrawable).setColor(if (i == active) C.CYAN else C.DOT_OFF)
        }
    }

    /** Called when the plan or API key changes, and every time the panel opens. */
    fun refresh() {
        badge.text = host.pro().label()
        appsPage.refresh()
        chatPage.refreshState()
        searchPage.refreshState()
    }

    /** Starts / stops the pulsing dot so nothing animates while the panel is hidden. */
    fun setActive(on: Boolean) {
        chatPage.setActive(on)
        searchPage.setActive(on)
    }

    fun animateIn(widthPx: Int) {
        animate().cancel()
        refresh()
        setActive(true)
        visibility = VISIBLE
        translationX = widthPx.toFloat()
        alpha = 0f
        animate().translationX(0f).alpha(1f).setDuration(250).setInterpolator(EASE).start()
    }

    fun animateOut(end: () -> Unit) {
        animate().cancel()
        animate().translationX(width.toFloat()).alpha(0f).setDuration(280).setInterpolator(EASE)
            .withEndAction { visibility = INVISIBLE; setActive(false); end() }.start()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_OUTSIDE) { onOutside?.invoke(); return true }
        return super.onTouchEvent(e)
    }

    private class PagesAdapter(val pages: List<View>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = pages.size
        override fun getItemViewType(position: Int) = position
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val v = pages[viewType]
            v.layoutParams = ViewGroup.LayoutParams(MATCH, MATCH)
            return object : RecyclerView.ViewHolder(v) {}
        }
        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {}
    }

    companion object {
        private val EASE = PathInterpolator(0.2f, 0f, 0f, 1f)
    }
}
