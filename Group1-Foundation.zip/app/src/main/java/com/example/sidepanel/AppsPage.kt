package com.example.sidepanel

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.provider.Settings
import android.text.TextUtils
import android.util.LruCache
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppItem(val label: String, val pkg: String)

/** A vertical list inside a vertical ViewPager2: scrolls itself first, hands over at the ends. */
class NestedRecycler(ctx: Context) : RecyclerView(ctx) {
    private var startY = 0f
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { startY = e.y; parent.requestDisallowInterceptTouchEvent(true) }
            MotionEvent.ACTION_MOVE -> {
                val dy = e.y - startY
                val keep = (dy > 0 && canScrollVertically(-1)) || (dy < 0 && canScrollVertically(1))
                parent.requestDisallowInterceptTouchEvent(keep)
            }
        }
        return super.dispatchTouchEvent(e)
    }
}

/** Page 1: favorite apps (2-col glass cards), File Dock, tool capsules. */
class AppsPage(private val ctx: Context, private val host: PanelHost) : LinearLayout(ctx) {
    private val all = ArrayList<AppItem>()
    private val shown = ArrayList<AppItem>()
    private val icons = LruCache<String, Drawable>(50)
    private val appAdapter = AppAdapter()
    private val dock: TextView

    init {
        orientation = VERTICAL
        addView(ctx.label("Apps & Tools", 13f, C.TEXT2), LayoutParams(MATCH, WRAP))

        dock = ctx.label("", 13f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ctx.dp(16), 0, ctx.dp(16), 0)
            background = ctx.glass(18)
            setOnClickListener { openDock() }
        }
        addView(dock, LayoutParams(MATCH, ctx.dp(52)).apply { topMargin = ctx.dp(8) })

        val tools = LinearLayout(ctx)
        listOf(
            "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS,
            "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
            "Settings" to Settings.ACTION_SETTINGS
        ).forEach { (name, action) ->
            tools.addView(ctx.capsule(name) { host.startActivity(Intent(action)) },
                LayoutParams(WRAP, WRAP).apply { rightMargin = ctx.dp(8) })
        }
        addView(tools, LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(8); bottomMargin = ctx.dp(4) })

        val rv = NestedRecycler(ctx).apply {
            layoutManager = GridLayoutManager(ctx, 2)
            adapter = appAdapter
            overScrollMode = OVER_SCROLL_NEVER
        }
        addView(rv, LayoutParams(MATCH, 0, 1f))

        refresh()
        host.scope.launch {   // load while dormant so the list is ready when the panel opens
            val items = withContext(Dispatchers.IO) {
                val pm = ctx.packageManager
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                pm.queryIntentActivities(intent, 0)
                    .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
                    .filter { it.pkg != ctx.packageName }
                    .distinctBy { it.pkg }
                    .sortedBy { it.label.lowercase() }
            }
            all.clear(); all.addAll(items)
            refresh()
        }
    }

    fun refresh() {
        val pro = host.pro().isPro
        dock.text = if (pro) "\uD83D\uDCC1  File Dock" else "\uD83D\uDD12  File Dock \u00b7 Pro"
        shown.clear()
        shown.addAll(if (pro) all else all.take(ProLogic.FREE_APPS))
        appAdapter.notifyDataSetChanged()
    }

    private fun openDock() {
        if (host.pro().isPro) host.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        else ctx.toast("File Dock is a Pro feature")
    }

    private inner class VH(val row: LinearLayout, val icon: ImageView, val label: TextView) :
        RecyclerView.ViewHolder(row)

    private inner class AppAdapter : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val row = LinearLayout(parent.context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(ctx.dp(10), 0, ctx.dp(10), 0)
                layoutParams = RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, ctx.dp(56))
                    .apply { setMargins(ctx.dp(4), ctx.dp(4), ctx.dp(4), ctx.dp(4)) }
                background = ctx.glass(18)
            }
            val icon = ImageView(parent.context)
            row.addView(icon, LayoutParams(ctx.dp(32), ctx.dp(32)))
            val label = ctx.label("", 11f, C.LABEL).apply {
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(ctx.dp(8), 0, 0, 0)
            }
            row.addView(label, LayoutParams(0, WRAP, 1f))
            return VH(row, icon, label)
        }

        override fun getItemCount() = shown.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val app = shown[position]
            h.label.text = app.label
            h.row.tag = app.pkg
            h.row.setOnClickListener { host.launchPackage(app.pkg) }
            val cached = icons.get(app.pkg)
            if (cached != null) {
                h.icon.setImageDrawable(cached)
            } else {
                h.icon.setImageDrawable(null)
                host.scope.launch {
                    val dr = withContext(Dispatchers.IO) {
                        runCatching { ctx.packageManager.getApplicationIcon(app.pkg) }.getOrNull()
                    }
                    if (dr != null) {
                        icons.put(app.pkg, dr)
                        if (h.row.tag == app.pkg) h.icon.setImageDrawable(dr)
                    }
                }
            }
        }
    }
}
