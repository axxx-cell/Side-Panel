package com.example.sidepanel

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import kotlin.math.ceil

enum class Plan { PRO, TRIAL, FREE }

class ProState(val plan: Plan, val daysLeft: Int) {
    val isPro: Boolean get() = plan != Plan.FREE
    fun label(): String = when (plan) {
        Plan.PRO -> "PRO"
        Plan.TRIAL -> "PRO trial \u00b7 ${daysLeft}d left"
        Plan.FREE -> "FREE"
    }
}

object ProLogic {
    private const val DAY = 24L * 60 * 60 * 1000
    const val FREE_APPS = 5

    fun state(p: Preferences, now: Long = System.currentTimeMillis()): ProState {
        // Step 3 will verify a signed license here. For now only the 3-day trial applies.
        if (!p[Keys.LICENSE].isNullOrEmpty()) return ProState(Plan.PRO, 0)
        val start = p[Keys.TRIAL_START] ?: return ProState(Plan.TRIAL, 3)
        val left = start + 3 * DAY - now
        return if (left > 0) ProState(Plan.TRIAL, ceil(left.toDouble() / DAY).toInt())
        else ProState(Plan.FREE, 0)
    }
}

/** The 3-day trial starts the first time the app or panel runs. */
suspend fun Context.ensureTrialStart() {
    applicationContext.dataStore.edit {
        if (it[Keys.TRIAL_START] == null) it[Keys.TRIAL_START] = System.currentTimeMillis()
    }
}
