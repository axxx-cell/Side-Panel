package com.example.sidepanel

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

object C {
    val CYAN = 0xFF00F5FF.toInt()
    val INDIGO = 0xFF6366F1.toInt()
    val GLASS = 0xCC2A2F5A.toInt()
    val TEXT2 = 0xFF8B9CC5.toInt()
    val LABEL = 0xFFCBD5E1.toInt()
    val GREEN = 0xFF00FF88.toInt()
    val RED = 0xFFFF5C7A.toInt()
    val DOT_OFF = 0xFF4A4F7A.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.glass(radiusDp: Int, color: Int = C.GLASS): GradientDrawable =
    GradientDrawable().apply { cornerRadius = dp(radiusDp).toFloat(); setColor(color) }

fun Context.label(text: CharSequence, sp: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text; textSize = sp; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

fun Context.capsule(text: String, onClick: () -> Unit): TextView =
    label(text, 12f).apply {
        background = glass(16, 0x802A2F5A.toInt())
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setOnClickListener { onClick() }
    }

fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

fun Context.isOnline(): Boolean {
    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/** Gemini returns markdown; the panel shows plain text. */
fun String.plainMd(): String = replace("**", "").replace("__", "")
    .replace(Regex("(?m)^\\s*[*-] "), "\u2022 ")
    .replace(Regex("(?m)^#+\\s*"), "")

/** The panel window is not focusable (so games don't pause). Typing turns focus on temporarily. */
fun EditText.openKeyboard(host: PanelHost) {
    host.setTyping(true)
    postDelayed({
        requestFocus()
        (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(this, 0)
    }, 150)
}

@SuppressLint("ClickableViewAccessibility")
fun EditText.overlayTyping(host: PanelHost) {
    setOnTouchListener { v, e ->
        if (e.action == MotionEvent.ACTION_DOWN) (v as EditText).openKeyboard(host)
        false
    }
}
