package com.example.sidepanel

import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Minimal Gemini REST client. Uses the USER'S OWN API key. search=true turns on Google Search grounding. */
object Gemini {
    private const val MODEL = "gemini-2.5-flash"

    class Source(val title: String, val url: String)
    class Result(val text: String, val sources: List<Source>)

    suspend fun ask(
        apiKey: String,
        history: List<Pair<String, String>>,   // role: "user" | "model"
        search: Boolean,
        system: String
    ): Result = withContext(Dispatchers.IO) {
        val contents = JSONArray()
        history.forEach { (role, text) ->
            contents.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val body = JSONObject()
            .put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        if (search) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey)
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(raw).getJSONObject("error").getString("message") }
                    .getOrDefault("Error $code")
                throw IllegalStateException(msg)
            }
            val cand = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
            val parts = cand.getJSONObject("content").getJSONArray("parts")
            val text = (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
            val sources = ArrayList<Source>()
            val chunks = cand.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
            if (chunks != null) {
                for (i in 0 until chunks.length()) {
                    val web = chunks.getJSONObject(i).optJSONObject("web") ?: continue
                    val link = web.optString("uri")
                    if (link.isNotEmpty() && sources.none { it.url == link }) {
                        sources.add(Source(web.optString("title", link), link))
                    }
                }
            }
            Result(text.trim(), sources)
        } finally {
            conn.disconnect()
        }
    }
}
