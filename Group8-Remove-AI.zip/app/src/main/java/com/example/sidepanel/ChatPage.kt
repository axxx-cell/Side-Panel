package com.example.sidepanel

// AI features were removed. This empty file replaces the old one.
