package com.example.sidepanel

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.CoroutineScope

/** What the panel needs from the service. */
interface PanelHost {
    val scope: CoroutineScope
    fun pro(): ProState
    suspend fun loadNote(): String
    fun saveNote(text: String)
    fun goBack()
    fun launchPackage(pkg: String)
    fun openApp()                    // opens the setup guide / settings screen
    fun setTyping(on: Boolean)       // makes the window focusable only while typing
    fun setExpanded(on: Boolean)     // compact card <-> wider card for chat, calculator, notes
    fun favorites(): List<String>
    fun setFavorites(list: List<String>)
    fun startActivity(i: Intent)
}

/** Invisible strip on the right edge + a small visible handle. Swipe left 30dp to open. */
class EdgeTrigger(context: Context, private val onOpen: () -> Unit) : FrameLayout(context) {
    private val d = resources.displayMetrics.density
    private val threshold = 30 * d
    private var downX = 0f
    private var opened = false

    init {
        val handle = View(context).apply {
            background = GradientDrawable().apply {
                cornerRadius = 4 * d
                setColor(withAlpha(C.CYAN, 0x99))
            }
        }
        addView(handle, LayoutParams((4 * d).toInt(), (56 * d).toInt(), Gravity.END or Gravity.CENTER_VERTICAL))
        addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            if (Build.VERSION.SDK_INT >= 29) {
                val h = b - t
                val w = r - l
                val ex = (200 * d).toInt().coerceAtMost(h)
                val top = (h - ex) / 2
                systemGestureExclusionRects = listOf(Rect(0, top, w, top + ex))
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.rawX; opened = false }
            MotionEvent.ACTION_MOVE ->
                if (!opened && downX - e.rawX >= threshold) { opened = true; onOpen() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> opened = false
        }
        return true
    }
}

/**
 * Compact card: favorite apps on the left, tools on the right, "Ask AI" below.
 * Calculator, Notes, Search, Chat and the app picker open in a wider card with a back arrow.
 */
class PanelView(context: Context, private val host: PanelHost) : LinearLayout(context) {

    var onOutside: (() -> Unit)? = null

    private enum class Screen { HOME, CALC, NOTES, PICKER }

    private val calcPage = CalcPage(context)
    private val notesPage = NotesPage(context, host)
    private val picker = AppPickerPage(context, host)
    private val home = HomeView(context, host) { id ->
        when (id) {
            "calc" -> go(Screen.CALC)
            "notes" -> go(Screen.NOTES)
            "picker" -> go(Screen.PICKER)
        }
    }
    private val backBtn: TextView
    private var screen = Screen.HOME
    private var active = false

    init {
        orientation = VERTICAL
        background = panelBackground()
        val base = context.dp(12)
        setPadding(base, base, base, base)
        ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.displayCutout())
            v.setPadding(base, base, base + i.right, base)
            insets
        }

        val bar = FrameLayout(context)
        val grabber = View(context).apply { background = context.glass(2, withAlpha(Color.WHITE, 0x33)) }
        bar.addView(grabber, FrameLayout.LayoutParams(context.dp(36), context.dp(4), Gravity.CENTER))
        backBtn = context.label("\u2190", 20f, C.CYAN, true).apply {
            gravity = Gravity.CENTER
            setOnClickListener { go(Screen.HOME) }
        }
        bar.addView(backBtn, FrameLayout.LayoutParams(context.dp(40), context.dp(32), Gravity.START or Gravity.CENTER_VERTICAL))
        addView(bar, LayoutParams(MATCH, context.dp(32)))

        val content = FrameLayout(context)
        listOf<View>(home, calcPage, notesPage, picker).forEach {
            content.addView(it, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        addView(content, LayoutParams(MATCH, 0, 1f))
        go(Screen.HOME)
    }

    private fun go(s: Screen) {
        screen = s
        val pages: Map<Screen, View> = mapOf(
            Screen.HOME to home, Screen.CALC to calcPage, Screen.NOTES to notesPage, Screen.PICKER to picker
        )
        pages.forEach { (k, v) -> v.visibility = if (k == s) VISIBLE else GONE }
        backBtn.visibility = if (s == Screen.HOME) INVISIBLE else VISIBLE
        host.setTyping(false)
        host.setExpanded(s != Screen.HOME)
        if (s == Screen.HOME) home.refresh()
        if (s == Screen.PICKER) picker.refresh()
    }

    fun resetToHome() = go(Screen.HOME)

    private fun panelBackground(): LayerDrawable {
        val r = context.dp(28).toFloat()
        val radii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
        val base = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(withAlpha(C.BG1, 0xF5), withAlpha(C.BG2, 0xF5))
        ).apply { cornerRadii = radii }
        fun blob(color: Int, cx: Float, cy: Float) = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = context.dp(220).toFloat()
            setGradientCenter(cx, cy)
            colors = intArrayOf(color, 0x00000000)
            cornerRadii = radii
        }
        return LayerDrawable(
            arrayOf(base, blob(withAlpha(C.CYAN, 0x1A), 0.9f, 0.1f), blob(withAlpha(C.INDIGO, 0x1A), 0.1f, 0.9f))
        )
    }

    /** Called when favorites, plan or API key change, and every time the panel opens. */
    fun refresh() {
        home.refresh()
        picker.refresh()
    }

    /** Pulsing dots only run while the panel is open. */
    fun setActive(on: Boolean) {
        active = on
    }

    fun animateIn(widthPx: Int) {
        animate().cancel()
        refresh()
        setActive(true)
        visibility = VISIBLE
        translationX = widthPx.toFloat()
        alpha = 0f
        animate().translationX(0f).alpha(1f).setDuration(250).setInterpolator(EASE).start()
    }

    fun animateOut(end: () -> Unit) {
        animate().cancel()
        animate().translationX(width.toFloat()).alpha(0f).setDuration(280).setInterpolator(EASE)
            .withEndAction { visibility = INVISIBLE; setActive(false); end() }.start()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_OUTSIDE) { onOutside?.invoke(); return true }
        return super.onTouchEvent(e)
    }

    companion object {
        private val EASE = PathInterpolator(0.2f, 0f, 0f, 1f)
    }
}
