package com.example.sidepanel

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Compact home: favorite apps (left), tools (right), "Ask AI" bar below. */
class HomeView(
    private val ctx: Context,
    private val host: PanelHost,
    private val onTool: (String) -> Unit
) : LinearLayout(ctx) {

    private val favList = LinearLayout(ctx).apply { orientation = VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
    private val toolList = LinearLayout(ctx).apply { orientation = VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }

    init {
        orientation = VERTICAL

        val cols = LinearLayout(ctx)
        cols.addView(scroller(favList), LayoutParams(0, MATCH, 1f))
        cols.addView(
            View(ctx).apply { setBackgroundColor(withAlpha(Color.WHITE, 0x22)) },
            LayoutParams(ctx.dp(1), MATCH).apply { setMargins(ctx.dp(4), ctx.dp(8), ctx.dp(4), ctx.dp(8)) }
        )
        cols.addView(scroller(toolList), LayoutParams(0, MATCH, 1f))
        addView(cols, LayoutParams(MATCH, 0, 1f))

        addTool("\uD83E\uDDEE", "Calculator") { onTool("calc") }
        addTool("\uD83D\uDCDD", "Notes") { onTool("notes") }
        addTool("\u21A9\uFE0F", "Last app") { host.goBack() }
        addTool("\uD83D\uDCC1", "File Dock") { openDock() }
        addTool("\uD83D\uDCF6", "Wi-Fi") { host.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        addTool("\u270F\uFE0F", "Edit apps") { onTool("picker") }
        addTool("\u2753", "Guide") { host.openApp() }

        refresh()
    }

    private fun scroller(child: View) = ScrollView(ctx).apply {
        isVerticalScrollBarEnabled = false
        overScrollMode = OVER_SCROLL_NEVER
        addView(child, ViewGroup.LayoutParams(MATCH, WRAP))
    }

    private fun openDock() {
        if (host.pro().isPro) host.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        else ctx.toast("File Dock is a Pro feature")
    }

    private fun addTool(icon: String, name: String, onClick: () -> Unit) {
        val col = LinearLayout(ctx).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, ctx.dp(6), 0, ctx.dp(6))
            setOnClickListener { onClick() }
        }
        val circle = ctx.label(icon, 18f).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(withAlpha(C.GLASS, 0xFF))
                setStroke(ctx.dp(1), withAlpha(C.CYAN, 0x55))
            }
        }
        col.addView(circle, LayoutParams(ctx.dp(42), ctx.dp(42)))
        col.addView(ctx.label(name, 10f, C.LABEL).apply {
            gravity = Gravity.CENTER; maxLines = 1; setPadding(0, ctx.dp(3), 0, 0)
        }, LayoutParams(MATCH, WRAP))
        toolList.addView(col, LayoutParams(MATCH, WRAP))
    }

    /** Rebuilds the favorites column. */
    fun refresh() {
        favList.removeAllViews()
        val favs = host.favorites()
        if (favs.isEmpty()) {
            favList.addView(
                ctx.label("No favorites yet.\nTap Edit apps.", 11f, C.TEXT2).apply {
                    gravity = Gravity.CENTER
                    setPadding(ctx.dp(4), ctx.dp(16), ctx.dp(4), 0)
                },
                ViewGroup.LayoutParams(MATCH, WRAP)
            )
            return
        }
        favs.forEach { addFavorite(it) }
    }

    @Suppress("DEPRECATION")
    private fun addFavorite(pkg: String) {
        val row = LinearLayout(ctx).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, ctx.dp(6), 0, ctx.dp(6))
            setOnClickListener { host.launchPackage(pkg) }
        }
        val icon = ImageView(ctx)
        val name = ctx.label("", 10f, C.LABEL).apply {
            gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            setPadding(ctx.dp(2), ctx.dp(3), ctx.dp(2), 0)
        }
        row.addView(icon, LayoutParams(ctx.dp(40), ctx.dp(40)))
        row.addView(name, LayoutParams(MATCH, WRAP))
        favList.addView(row, LayoutParams(MATCH, WRAP))
        host.scope.launch {
            val info = withContext(Dispatchers.IO) {
                runCatching {
                    val pm = ctx.packageManager
                    Pair(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString(), pm.getApplicationIcon(pkg))
                }.getOrNull()
            }
            if (info == null) favList.removeView(row)
            else { name.text = info.first; icon.setImageDrawable(info.second) }
        }
    }
}
