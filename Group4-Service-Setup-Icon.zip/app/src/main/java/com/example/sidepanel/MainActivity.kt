package com.example.sidepanel

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import androidx.activity.ComponentActivity
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Setup guide (tutorials), trial status, API key entry and settings. */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch { applicationContext.ensureTrialStart() }
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch { render(dataStore.data.first()) }   // re-check the steps when you come back
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        return s?.contains("$packageName/") == true
    }

    private fun addStep(
        root: LinearLayout, n: Int, title: String, body: String, done: Boolean,
        extra: View? = null, actions: List<Pair<String, () -> Unit>> = emptyList()
    ) {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(18)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        c.addView(label((if (done) "\u2713  " else "$n.  ") + title, 15f, if (done) C.GREEN else Color.WHITE, true))
        c.addView(label(body, 13f, C.LABEL).apply { setPadding(0, dp(6), 0, dp(4)) })
        if (extra != null) c.addView(extra, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        actions.forEach { (t, f) ->
            c.addView(capsule(t, f), LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(8) })
        }
        root.addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) })
    }

    private fun section(root: LinearLayout, title: String) {
        root.addView(label(title, 18f, Color.WHITE, true).apply { setPadding(0, dp(20), 0, dp(10)) })
    }

    private fun render(p: Preferences) {
        val state = ProLogic.state(p)
        val hasKey = !p[Keys.API_KEY].isNullOrBlank()
        val on = serviceOn()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(32))
        }

        // ---- status ----
        root.addView(label("Side Panel", 28f, Color.WHITE, true))
        root.addView(
            label(state.label(), 12f, C.CYAN).apply {
                background = glass(12, 0x332A2F5A)
                setPadding(dp(10), dp(4), dp(10), dp(4))
            },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(8) }
        )
        val statusText = when (state.plan) {
            Plan.TRIAL -> "Your free Pro trial has ${state.daysLeft} day(s) left. Every feature is unlocked."
            Plan.PRO -> "Pro is active. Thank you for supporting the app!"
            Plan.FREE -> "Your trial has ended. Free plan: 5 apps, no File Dock. Payment options are coming in a future update."
        }
        root.addView(label(statusText, 13f, C.LABEL).apply { setPadding(0, dp(10), 0, 0) })

        // ---- tutorials ----
        section(root, "Setup guide")

        addStep(
            root, 1, "Allow restricted settings",
            "If you installed this app from outside the Play Store, Android 13+ may grey out the Accessibility switch.\n" +
                "1. Tap \"Open App info\".\n2. Tap the \u22ee menu at the top-right.\n" +
                "3. Tap \"Allow restricted settings\" and confirm.\n(No \u22ee menu? Skip this step.)",
            on,
            actions = listOf("Open App info" to {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            })
        )

        addStep(
            root, 2, "Turn on the panel",
            "1. Tap \"Open Accessibility\".\n2. Find Side Panel (under Installed apps or Downloaded apps).\n" +
                "3. Switch it ON and tap Allow.\nThis step shows a green check when it is on.",
            on,
            actions = listOf("Open Accessibility" to { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        )

        addStep(
            root, 3, "Open the panel",
            "Swipe left from the small cyan handle on the right edge of the screen. It works in portrait and in landscape games.\n" +
                "Swipe up or down inside the panel to change pages (5 dots at the bottom).\n" +
                "The \u2190 button returns to the app you were using. The ? button opens this guide.\n" +
                "Panel won't open? Set the trigger width to 24dp below.",
            false
        )

        addStep(
            root, 4, "Get your free AI key",
            "The AI pages use your own free Gemini key.\n1. Tap \"Open Google AI Studio\" and sign in with a Google account.\n" +
                "2. Tap \"Create API key\".\n3. Copy the key (a long text starting with AIza).\n4. Come back here and paste it in step 5.",
            hasKey,
            actions = listOf("Open Google AI Studio" to {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey")))
            })
        )

        val keyField = EditText(this).apply {
            hint = "Paste your key here"
            setHintTextColor(C.TEXT2)
            setTextColor(Color.WHITE)
            textSize = 13f
            setSingleLine(true)
            background = glass(14, 0x55FFFFFF)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        addStep(
            root, 5, "Paste your key",
            if (hasKey) "A key is saved. Paste a new one to replace it." else "Paste the key and tap Save. It is stored only on this phone.",
            hasKey,
            extra = keyField,
            actions = listOf("Save key" to {
                val k = keyField.text.toString().trim()
                if (k.length < 20) toast("That does not look like a key")
                else lifecycleScope.launch {
                    dataStore.edit { it[Keys.API_KEY] = k }
                    toast("Key saved")
                    render(dataStore.data.first())
                }
            })
        )

        // ---- settings ----
        section(root, "Settings")
        val nav = runCatching { Settings.Secure.getInt(contentResolver, "navigation_mode", 0) }.getOrDefault(0)
        val defaultDp = if (nav == 2) 12 else 18
        root.addView(label("Edge trigger width", 14f, C.LABEL))
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf(12, 18, 24).forEach { v ->
            group.addView(RadioButton(this).apply { id = v; text = "${v}dp"; setTextColor(Color.WHITE) })
        }
        group.check(p[Keys.TRIGGER_DP] ?: defaultDp)
        group.setOnCheckedChangeListener { _, id ->
            lifecycleScope.launch { dataStore.edit { it[Keys.TRIGGER_DP] = id } }
        }
        root.addView(group)

        val landscape = Switch(this).apply {
            text = "Enable in landscape games"
            setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, 0)
            isChecked = p[Keys.LANDSCAPE] ?: true
            setOnCheckedChangeListener { _, checked ->
                lifecycleScope.launch { dataStore.edit { it[Keys.LANDSCAPE] = checked } }
            }
        }
        root.addView(landscape)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF181E3A.toInt())
            addView(root)
        })
    }
}
