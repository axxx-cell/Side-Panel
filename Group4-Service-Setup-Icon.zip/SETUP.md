# Side Panel - setup (all groups)

## 1. Files
Unzip Group 1, 2, 3a and 4 into your project root. Replace files with the same name.
Everything uses `package com.example.sidepanel` and lives in `app/src/main/java/com/example/sidepanel/`.
Use your real package name: change the `package` line in every .kt file and move the folder to match.

## 2. Delete the old pieces
- Old OverlayService, its foreground-service code, and the old MainActivity / PanelView from before.
- Old launcher icons named ic_launcher / ic_launcher_round in mipmap folders (the new adaptive icon replaces them),
  and any old ic_launcher_foreground / ic_launcher_background in drawable.
- Permissions SYSTEM_ALERT_WINDOW and FOREGROUND_SERVICE (not needed any more).

## 3. AndroidManifest.xml
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

<queries>
    <intent>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
    </intent>
</queries>

<application
    android:icon="@mipmap/ic_launcher"
    android:roundIcon="@mipmap/ic_launcher_round"
    ... >
    <activity android:name=".MainActivity" android:exported="true">
        <intent-filter>
            <action android:name="android.intent.action.MAIN" />
            <category android:name="android.intent.category.LAUNCHER" />
        </intent-filter>
    </activity>

    <service
        android:name=".PanelAccessibilityService"
        android:exported="false"
        android:label="Side Panel"
        android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
        <intent-filter>
            <action android:name="android.accessibilityservice.AccessibilityService" />
        </intent-filter>
        <meta-data
            android:name="android.accessibilityservice"
            android:resource="@xml/accessibility_service_config" />
    </service>
</application>
```

## 4. app/build.gradle dependencies
```
implementation("androidx.core:core-ktx:1.13.1")
implementation("androidx.activity:activity-ktx:1.9.0")
implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.0")
implementation("androidx.recyclerview:recyclerview:1.3.2")
implementation("androidx.viewpager2:viewpager2:1.1.0")
implementation("androidx.datastore:datastore-preferences:1.1.1")
implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
```

## 5. After installing the APK
Open the app: the Setup guide walks through the rest
(restricted settings, Accessibility, the swipe, getting and pasting your free Gemini key).

## 6. Test checklist
- Swipe left from the right edge: panel opens fast, in portrait and landscape games
- Works in gesture navigation and 3-button navigation
- Swipe up/down inside the panel: 5 pages, dots follow
- Back arrow returns to the app you were in
- AI Assistant: paste a key, send a message, close and reopen the panel: the conversation is still there
- Notes: type (keyboard opens), close the panel, reopen: text is saved
- Setup guide steps show green checks when done; the badge shows "PRO trial - 3d left"
