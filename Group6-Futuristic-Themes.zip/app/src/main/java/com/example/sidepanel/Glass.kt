package com.example.sidepanel

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class Palette(val accent: Int, val accent2: Int, val glass: Int, val bg1: Int, val bg2: Int, val dot: Int)

object C {
    var CYAN = 0xFF00F5FF.toInt()      // main accent (changes with the theme)
    var INDIGO = 0xFF6366F1.toInt()    // second accent
    var GLASS = 0xCC373E7A.toInt()     // card color
    var BG1 = 0xFF0B1026.toInt()
    var BG2 = 0xFF1A1245.toInt()
    var DOT_OFF = 0xFF4A4F7A.toInt()
    var TEXT2 = 0xFF8B9CC5.toInt()
    val LABEL = 0xFFCBD5E1.toInt()
    val GREEN = 0xFF00FF88.toInt()
    val RED = 0xFFFF5C7A.toInt()

    val THEMES = listOf("Neon", "Aurora", "AMOLED", "Plasma")
    val PALETTES = listOf(
        Palette(0xFF00F5FF.toInt(), 0xFF6366F1.toInt(), 0xCC373E7A.toInt(), 0xFF0B1026.toInt(), 0xFF1A1245.toInt(), 0xFF4A4F7A.toInt()),
        Palette(0xFF00FFA3.toInt(), 0xFF7C4DFF.toInt(), 0xCC2F4A66.toInt(), 0xFF071A2B.toInt(), 0xFF1B1B45.toInt(), 0xFF3F5A73.toInt()),
        Palette(0xFF00F5FF.toInt(), 0xFF6366F1.toInt(), 0xCC1C1C26.toInt(), 0xFF000000.toInt(), 0xFF07070D.toInt(), 0xFF33334A.toInt()),
        Palette(0xFFFF3DCB.toInt(), 0xFFFF8A3D.toInt(), 0xCC4A2A6B.toInt(), 0xFF17082B.toInt(), 0xFF2E1048.toInt(), 0xFF5A3F7A.toInt())
    )

    fun applyTheme(i: Int) {
        val p = PALETTES[i.coerceIn(0, PALETTES.size - 1)]
        CYAN = p.accent; INDIGO = p.accent2; GLASS = p.glass
        BG1 = p.bg1; BG2 = p.bg2; DOT_OFF = p.dot
    }
}

fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

/** Futuristic backdrop: dark gradient with two soft aurora glows. */
fun Context.aurora(): LayerDrawable {
    fun blob(color: Int, cx: Float, cy: Float) = GradientDrawable().apply {
        gradientType = GradientDrawable.RADIAL_GRADIENT
        gradientRadius = dp(300).toFloat()
        setGradientCenter(cx, cy)
        colors = intArrayOf(color, 0x00000000)
    }
    val base = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.BG1, C.BG2))
    return LayerDrawable(arrayOf(base, blob(withAlpha(C.CYAN, 0x2A), 0.9f, 0.05f), blob(withAlpha(C.INDIGO, 0x2A), 0.05f, 0.95f)))
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.glass(radiusDp: Int, color: Int = C.GLASS): GradientDrawable =
    GradientDrawable().apply { cornerRadius = dp(radiusDp).toFloat(); setColor(color); setStroke(dp(1), 0x22FFFFFF) }

fun Context.label(text: CharSequence, sp: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text; textSize = sp; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

fun Context.capsule(text: String, onClick: () -> Unit): TextView =
    label(text, 12f).apply {
        background = glass(16, withAlpha(C.GLASS, 0xFF))
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setOnClickListener { onClick() }
    }

fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

fun Context.isOnline(): Boolean {
    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/** Gemini returns markdown; the panel shows plain text. */
fun String.plainMd(): String = replace("**", "").replace("__", "")
    .replace(Regex("(?m)^\\s*[*-] "), "\u2022 ")
    .replace(Regex("(?m)^#+\\s*"), "")

/** The panel window is not focusable (so games don't pause). Typing turns focus on temporarily. */
fun EditText.openKeyboard(host: PanelHost) {
    host.setTyping(true)
    postDelayed({
        requestFocus()
        (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(this, 0)
    }, 150)
}

@SuppressLint("ClickableViewAccessibility")
fun EditText.overlayTyping(host: PanelHost) {
    setOnTouchListener { v, e ->
        if (e.action == MotionEvent.ACTION_DOWN) (v as EditText).openKeyboard(host)
        false
    }
}
