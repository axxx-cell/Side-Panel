package com.example.sidepanel

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.launch
import org.json.JSONArray

/**
 * Page 4: simple AI chat. No daily limit from the app (it uses the user's own Gemini key).
 * The conversation is saved on the phone and restored every time the panel starts.
 */
class ChatPage(private val ctx: Context, private val host: PanelHost) : LinearLayout(ctx) {

    private val dot = View(ctx).apply {
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C.GREEN) }
    }
    private val pulse = ObjectAnimator.ofFloat(dot, View.ALPHA, 1f, 0.25f).apply {
        duration = 900
        repeatMode = ValueAnimator.REVERSE
        repeatCount = ValueAnimator.INFINITE
    }
    private val banner = ctx.label("Offline - AI needs internet", 12f).apply {
        background = ctx.glass(12, 0x88FF5C7A.toInt())
        setPadding(ctx.dp(10), ctx.dp(6), ctx.dp(10), ctx.dp(6))
        visibility = GONE
    }
    private val setup = ctx.label(
        "Add your free Gemini key to use AI. Tap here for the step-by-step guide.", 12f, C.CYAN
    ).apply {
        background = ctx.glass(12)
        setPadding(ctx.dp(10), ctx.dp(8), ctx.dp(10), ctx.dp(8))
        visibility = GONE
        setOnClickListener { host.openApp() }
    }
    private val list = LinearLayout(ctx).apply { orientation = VERTICAL }
    private val scroll = ScrollView(ctx)
    private val input = EditText(ctx)
    private val store = ctx.getSharedPreferences("chat", Context.MODE_PRIVATE)
    private val history = ArrayList<Pair<String, String>>()   // ("user" | "model") to text
    private var busy = false

    init {
        orientation = VERTICAL

        val head = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(dot, LayoutParams(ctx.dp(8), ctx.dp(8)).apply { rightMargin = ctx.dp(8) })
        head.addView(ctx.label("AI Assistant", 16f, Color.WHITE, true), LayoutParams(0, WRAP, 1f))
        head.addView(ctx.capsule("New chat") { newChat() })
        addView(head, LayoutParams(MATCH, WRAP))

        addView(banner, LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(6) })
        addView(setup, LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(6) })

        scroll.addView(list, LayoutParams(MATCH, WRAP))
        addView(scroll, LayoutParams(MATCH, 0, 1f).apply { topMargin = ctx.dp(6) })

        input.apply {
            hint = "Ask anything\u2026"
            setHintTextColor(C.TEXT2)
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 3
            background = ctx.glass(18)
            setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(14), ctx.dp(10))
        }
        input.overlayTyping(host)   // window focus is switched on only while typing
        val sendBtn = ctx.label("\u27a4", 20f, C.CYAN, true).apply {
            gravity = Gravity.CENTER
            setOnClickListener { submit() }
        }
        val row = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(input, LayoutParams(0, WRAP, 1f))
        row.addView(sendBtn, LayoutParams(ctx.dp(44), ctx.dp(44)))
        addView(row, LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(6) })

        load()
    }

    // ---------- saved conversation ----------

    private fun load() {
        runCatching {
            val arr = JSONArray(store.getString("h", "[]"))
            for (i in 0 until arr.length()) {
                val p = arr.getJSONArray(i)
                history.add(p.getString(0) to p.getString(1))
                bubble(p.getString(1), p.getString(0) == "user")
            }
        }
    }

    private fun save() {
        val arr = JSONArray()
        history.takeLast(100).forEach { (role, text) -> arr.put(JSONArray().put(role).put(text)) }
        store.edit().putString("h", arr.toString()).apply()
    }

    private fun newChat() {
        history.clear()
        list.removeAllViews()
        save()
    }

    // ---------- chat ----------

    private fun bubble(text: String, user: Boolean): TextView {
        val tv = ctx.label(if (user) text else text.plainMd(), 13f).apply {
            maxWidth = ctx.dp(250)
            setPadding(ctx.dp(12), ctx.dp(8), ctx.dp(12), ctx.dp(8))
            background = ctx.glass(16, if (user) withAlpha(C.INDIGO, 0xCC) else C.GLASS)
        }
        list.addView(tv, LayoutParams(WRAP, WRAP).apply {
            gravity = if (user) Gravity.END else Gravity.START
            topMargin = ctx.dp(6)
        })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private fun submit() {
        val text = input.text.toString().trim()
        if (text.isEmpty() || busy) return
        host.setTyping(false)
        if (host.apiKey().isBlank()) { refreshState(); return }
        if (!ctx.isOnline()) { banner.visibility = VISIBLE; return }
        banner.visibility = GONE

        input.setText("")
        bubble(text, true)
        history.add("user" to text)
        val reply = bubble("\u2026", false)
        busy = true
        host.scope.launch {
            try {
                // Gemini wants the conversation to start with a user message
                val turns = history.takeLast(30).dropWhile { it.first != "user" }
                val r = Gemini.ask(host.apiKey(), turns, false, SYSTEM)
                reply.text = r.text.plainMd()
                history.add("model" to r.text)
            } catch (e: Exception) {
                reply.text = "\u26a0 ${e.message ?: "Request failed"}"
                history.removeAt(history.lastIndex)
            }
            busy = false
            save()
        }
    }

    // ---------- called by the panel ----------

    fun refreshState() {
        setup.visibility = if (host.apiKey().isBlank()) VISIBLE else GONE
        banner.visibility = if (ctx.isOnline()) GONE else VISIBLE
    }

    /** Pulsing dot only runs while the panel is open. */
    fun setActive(on: Boolean) {
        if (on) { pulse.start(); refreshState() } else pulse.cancel()
    }

    companion object {
        private const val SYSTEM =
            "You are a helpful, concise assistant inside a phone side panel. Reply in plain text."
    }
}
