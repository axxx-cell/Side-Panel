package com.example.sidepanel

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.widget.LinearLayout
import android.widget.TextView

/** Page 2: mini glass calculator with haptics and a short history. */
class CalcPage(private val ctx: Context) : LinearLayout(ctx) {
    private val div = "\u00f7"
    private val mul = "\u00d7"
    private val sub = "\u2212"
    private val ops = setOf(div, mul, sub, "+")

    private var expr = ""
    private val history = ArrayList<String>()
    private val hist = ctx.label("", 11f, C.TEXT2).apply { gravity = Gravity.END; maxLines = 3 }
    private val disp = ctx.label("0", 30f, Color.WHITE).apply { gravity = Gravity.END; maxLines = 1 }

    init {
        orientation = VERTICAL
        addView(ctx.label("Calculator", 13f, C.TEXT2), LayoutParams(MATCH, WRAP))
        addView(hist, LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(6) })
        addView(disp, LayoutParams(MATCH, WRAP))

        val pad = LinearLayout(ctx).apply { orientation = VERTICAL }
        val rows = listOf(
            listOf("C", "\u232b", "%", div),
            listOf("7", "8", "9", mul),
            listOf("4", "5", "6", sub),
            listOf("1", "2", "3", "+"),
            listOf("00", "0", ".", "=")
        )
        val m = ctx.dp(3)
        rows.forEach { row ->
            val r = LinearLayout(ctx)
            row.forEach { k -> r.addView(key(k), LayoutParams(0, MATCH, 1f).apply { setMargins(m, m, m, m) }) }
            pad.addView(r, LayoutParams(MATCH, 0, 1f))
        }
        // keys share the leftover height, so it also fits short landscape screens
        addView(pad, LayoutParams(MATCH, 0, 1f).apply { topMargin = ctx.dp(8) })
    }

    private fun key(k: String): TextView {
        val bg = when {
            k == "=" -> C.CYAN
            k in ops || k == "C" -> 0xCC6366F1.toInt()
            else -> C.GLASS
        }
        return ctx.label(k, 18f, if (k == "=") Color.BLACK else Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = ctx.glass(14, bg)
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                press(k)
            }
        }
    }

    private fun press(k: String) {
        when (k) {
            "C" -> expr = ""
            "\u232b" -> expr = expr.dropLast(1)
            "=" -> if (expr.isNotEmpty()) {
                val r = calc(expr)
                history.add(0, "$expr = $r")
                if (history.size > 3) history.removeAt(3)
                hist.text = history.joinToString("\n")
                expr = if (r == "Error") "" else r
            }
            in ops -> when {
                expr.isEmpty() -> if (k == sub) expr = sub
                expr.last().toString() in ops -> expr = expr.dropLast(1) + k
                else -> expr += k
            }
            else -> expr += k
        }
        disp.text = expr.ifEmpty { "0" }
    }

    private fun calc(s: String): String = runCatching {
        var i = 0
        fun peek(): Char = if (i < s.length) s[i] else '\u0000'
        fun num(): Double {
            val st = i
            while (peek().isDigit() || peek() == '.') i++
            return s.substring(st, i).toDouble()
        }
        fun factor(): Double {
            if (peek() == '\u2212') { i++; return -factor() }
            val v = num()
            if (peek() == '%') { i++; return v / 100 }
            return v
        }
        fun term(): Double {
            var v = factor()
            while (peek() == '\u00d7' || peek() == '\u00f7') {
                val op = s[i++]
                val r = factor()
                v = if (op == '\u00d7') v * r else v / r
            }
            return v
        }
        fun sum(): Double {
            var v = term()
            while (peek() == '+' || peek() == '\u2212') {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }
        val v = sum()
        if (i != s.length) "Error" else fmt(v)
    }.getOrDefault("Error")

    private fun fmt(v: Double): String {
        if (v.isNaN() || v.isInfinite()) return "Error"
        val s = if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else "%.8f".format(v).trimEnd('0').trimEnd('.')
        return s.replace('-', '\u2212')
    }
}
