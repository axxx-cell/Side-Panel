package com.example.sidepanel

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import androidx.core.widget.doAfterTextChanged
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Page 3: glass notes with auto-save (DataStore) and export. */
class NotesPage(private val ctx: Context, private val host: PanelHost) : LinearLayout(ctx) {
    private val et = EditText(ctx)
    private var saveJob: Job? = null

    init {
        orientation = VERTICAL
        val top = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(ctx.label("Notes", 13f, C.TEXT2), LayoutParams(0, WRAP, 1f))
        top.addView(ctx.capsule("Export") { export() })
        addView(top, LayoutParams(MATCH, WRAP))

        et.apply {
            hint = "Write a note\u2026"
            setHintTextColor(C.TEXT2)
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.TOP or Gravity.START
            background = ctx.glass(18)
            setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        }
        addView(et, LayoutParams(MATCH, 0, 1f).apply { topMargin = ctx.dp(8) })
        et.overlayTyping(host)   // focus is switched on only while typing

        host.scope.launch {
            et.setText(host.loadNote())
            et.doAfterTextChanged { text ->
                saveJob?.cancel()
                saveJob = host.scope.launch {
                    delay(600)
                    host.saveNote(text?.toString().orEmpty())
                }
            }
        }
    }

    private fun export() {
        val text = et.text.toString()
        if (text.isBlank()) { ctx.toast("Nothing to export"); return }
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        host.startActivity(Intent.createChooser(send, "Export note"))
    }
}
