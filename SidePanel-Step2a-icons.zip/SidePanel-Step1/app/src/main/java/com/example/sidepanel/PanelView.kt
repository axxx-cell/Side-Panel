package com.example.sidepanel

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.TextUtils
import android.util.LruCache
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Invisible strip on the right edge + a small visible handle. Swipe left 30dp to open. */
class EdgeTrigger(context: Context, private val onOpen: () -> Unit) : FrameLayout(context) {
    private val d = resources.displayMetrics.density
    private val threshold = 30 * d
    private var downX = 0f
    private var opened = false

    init {
        val handle = View(context).apply {
            background = GradientDrawable().apply {
                cornerRadius = 4 * d
                setColor(0x9900F5FF.toInt())
            }
        }
        addView(handle, LayoutParams((4 * d).toInt(), (56 * d).toInt(), Gravity.END or Gravity.CENTER_VERTICAL))

        // Ask Android to give this strip priority over the system back-swipe (max ~200dp).
        addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            if (Build.VERSION.SDK_INT >= 29) {
                val h = b - t
                val w = r - l
                val ex = (200 * d).toInt().coerceAtMost(h)
                val top = (h - ex) / 2
                systemGestureExclusionRects = listOf(Rect(0, top, w, top + ex))
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.rawX; opened = false }
            MotionEvent.ACTION_MOVE ->
                if (!opened && downX - e.rawX >= threshold) { opened = true; onOpen() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> opened = false
        }
        return true
    }
}

class AppItem(val label: String, val pkg: String)

/** The panel. Built once and kept dormant (INVISIBLE) so opening is instant. */
class PanelView(
    context: Context,
    private val scope: CoroutineScope,
    private val onBack: () -> Unit,
    private val onLaunch: (String) -> Unit,
    private val onCool: () -> Unit
) : LinearLayout(context) {

    var onOutside: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private val iconCache = LruCache<String, Drawable>(50)
    private val apps = ArrayList<AppItem>()
    private val appAdapter = AppAdapter()
    private lateinit var refreshBtn: ImageView

    init {
        orientation = VERTICAL
        val r = dp(24).toFloat()
        background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xF2181E3A.toInt(), 0xF2211E4A.toInt())
        ).apply { cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r) }

        val base = dp(12)
        setPadding(base, base, base, base)
        ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(base, i.top + base, i.right + base, i.bottom + base)
            insets
        }

        val header = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(iconButton(R.drawable.ic_back, Color.WHITE) { onBack() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        header.addView(TextView(context).apply {
            text = "Side Panel"; textSize = 16f; setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        refreshBtn = iconButton(R.drawable.ic_refresh, ACCENT) { refresh() }
        header.addView(refreshBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
        header.addView(iconButton(R.drawable.ic_cool, ACCENT) { onCool() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val rv = RecyclerView(context).apply {
            layoutManager = GridLayoutManager(context, 2)
            adapter = appAdapter
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        addView(rv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        loadApps() // pre-load while dormant so the list is ready when opened
    }

    private fun iconButton(res: Int, tint: Int, onClick: () -> Unit) = ImageView(context).apply {
        setImageResource(res)
        setColorFilter(tint)
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setOnClickListener { onClick() }
    }

    /** Reloads the app list and spins the refresh icon once. */
    fun refresh() {
        iconCache.evictAll()
        loadApps()
        refreshBtn.animate().cancel()
        refreshBtn.rotation = 0f
        refreshBtn.animate().rotation(360f).setDuration(500).setInterpolator(EASE).start()
    }

    private fun loadApps() {
        scope.launch {
            val items = withContext(Dispatchers.IO) {
                val pm = context.packageManager
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                pm.queryIntentActivities(intent, 0)
                    .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
                    .filter { it.pkg != context.packageName }
                    .distinctBy { it.pkg }
                    .sortedBy { it.label.lowercase() }
            }
            apps.clear(); apps.addAll(items)
            appAdapter.notifyDataSetChanged()
        }
    }

    fun animateIn(widthPx: Int) {
        animate().cancel()
        visibility = VISIBLE
        translationX = widthPx.toFloat()
        alpha = 0f
        animate().translationX(0f).alpha(1f).setDuration(250).setInterpolator(EASE).start()
    }

    fun animateOut(end: () -> Unit) {
        animate().cancel()
        animate().translationX(width.toFloat()).alpha(0f).setDuration(280).setInterpolator(EASE)
            .withEndAction { visibility = INVISIBLE; end() }.start()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_OUTSIDE) { onOutside?.invoke(); return true }
        return super.onTouchEvent(e)
    }

    private inner class VH(val row: LinearLayout, val icon: ImageView, val label: TextView) :
        RecyclerView.ViewHolder(row)

    private inner class AppAdapter : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val row = LinearLayout(parent.context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(10), 0)
                layoutParams = RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, dp(56))
                    .apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
                background = GradientDrawable().apply {
                    cornerRadius = dp(18).toFloat(); setColor(0xCC2A2F5A.toInt())
                }
            }
            val icon = ImageView(parent.context)
            row.addView(icon, LinearLayout.LayoutParams(dp(32), dp(32)))
            val label = TextView(parent.context).apply {
                textSize = 11f; setTextColor(0xFFCBD5E1.toInt())
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(dp(8), 0, 0, 0)
            }
            row.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            return VH(row, icon, label)
        }

        override fun getItemCount() = apps.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val app = apps[position]
            h.label.text = app.label
            h.row.tag = app.pkg
            h.row.setOnClickListener { onLaunch(app.pkg) }
            val cached = iconCache.get(app.pkg)
            if (cached != null) {
                h.icon.setImageDrawable(cached)
            } else {
                h.icon.setImageDrawable(null)
                scope.launch {
                    val dr = withContext(Dispatchers.IO) {
                        runCatching { context.packageManager.getApplicationIcon(app.pkg) }.getOrNull()
                    }
                    if (dr != null) {
                        iconCache.put(app.pkg, dr)
                        if (h.row.tag == app.pkg) h.icon.setImageDrawable(dr)
                    }
                }
            }
        }
    }

    companion object {
        private val EASE = PathInterpolator(0.2f, 0f, 0f, 1f)
        private const val ACCENT = 0xFF00F5FF.toInt()
    }
}
