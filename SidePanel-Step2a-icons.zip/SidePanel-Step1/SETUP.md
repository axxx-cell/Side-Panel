# Side Panel - Step 1 setup

## 1. Package name
Files use `package com.example.sidepanel` and sit in `app/src/main/java/com/example/sidepanel/`.
Use your real package name: change the `package` line in each .kt file and move the folder to match.

## 2. Delete the old pieces
Remove the old OverlayService, its foreground-service code, and the SYSTEM_ALERT_WINDOW and
FOREGROUND_SERVICE permissions. The AccessibilityService now owns the overlay.

## 3. AndroidManifest.xml (inside <manifest>, and <application>)
```xml
<queries>
    <intent>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
    </intent>
</queries>

<application ...>
    <activity android:name=".MainActivity" android:exported="true">
        <intent-filter>
            <action android:name="android.intent.action.MAIN" />
            <category android:name="android.intent.category.LAUNCHER" />
        </intent-filter>
    </activity>

    <service
        android:name=".PanelAccessibilityService"
        android:exported="false"
        android:label="Side Panel"
        android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
        <intent-filter>
            <action android:name="android.accessibilityservice.AccessibilityService" />
        </intent-filter>
        <meta-data
            android:name="android.accessibilityservice"
            android:resource="@xml/accessibility_service_config" />
    </service>
</application>
```

## 4. app/build.gradle dependencies
```
implementation("androidx.core:core-ktx:1.13.1")
implementation("androidx.activity:activity-ktx:1.9.0")
implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.0")
implementation("androidx.recyclerview:recyclerview:1.3.2")
implementation("androidx.datastore:datastore-preferences:1.1.1")
implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
```

## 5. After installing the APK (sideloaded)
Android 13+ blocks accessibility for sideloaded apps until you allow it:
Settings > Apps > Side Panel > (three dots) > "Allow restricted settings".
Then Settings > Accessibility > Side Panel > turn on.

## 6. Test checklist
- Swipe left from the right edge: panel opens in under 0.25s
- Works in gesture navigation and 3-button navigation
- Rotate to landscape (and open MLBB / CODM horizontally): swipe still opens it
- Open an app, then open the panel and tap the back arrow: you return to that app
- Settings screen: change trigger width 12/18/24dp, toggle landscape

## Step 2a - icons (no emojis)
- New files in app/src/main/res/drawable/: ic_back.xml, ic_refresh.xml, ic_cool.xml
- Add to AndroidManifest.xml (inside <manifest>): <uses-permission android:name="android.permission.KILL_BACKGROUND_PROCESSES" />
- Replace PanelView.kt and PanelAccessibilityService.kt with the ones in this zip
